import type * as React from 'react';
import type { ColorValue } from 'react-native';
import type { StackHeaderConfigProps, StackHeaderConfigRef } from 'react-native-screens';
import type { NativeStackNavigationOptions } from '../../types.js';
export type HeaderConfigOptions = {
    options: NativeStackNavigationOptions;
    hasCustomHeader: boolean;
    headerLeftElement: React.ReactNode;
    headerRightElement: React.ReactNode;
    headerTitleElement: React.ReactNode;
    headerTitleText: string;
    canGoBack: boolean;
    tintColor: ColorValue;
    isRemovePrevented: boolean;
};
export type HeaderConfigResult = {
    platformConfig: Pick<StackHeaderConfigProps, 'android' | 'ios'>;
    headerConfigRef?: React.RefObject<StackHeaderConfigRef | null> | undefined;
    usesHeaderLeftElement: boolean;
    headerBackgroundMode: 'native' | 'screen' | 'none';
};
export declare function useHeaderConfig({ headerLeftElement, }: HeaderConfigOptions): HeaderConfigResult;
//# sourceMappingURL=useHeaderConfig.d.ts.map