import { type ParamListBase, type StackNavigationState } from '@react-navigation/native';
import * as React from 'react';
import type { NativeStackDescriptorMap, NativeStackNavigationHelpers } from '../../types.js';
type Props = {
    state: StackNavigationState<ParamListBase>;
    navigation: NativeStackNavigationHelpers;
    descriptors: NativeStackDescriptorMap;
};
export declare function NativeStackView({ state, navigation, descriptors }: Props): React.JSX.Element;
export {};
//# sourceMappingURL=NativeStackView.native.d.ts.map