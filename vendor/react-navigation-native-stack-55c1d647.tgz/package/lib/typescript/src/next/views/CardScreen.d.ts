import * as React from 'react';
import type { NativeStackDescriptor, NativeStackNavigationHelpers } from '../../types.js';
type Props = {
    descriptor: NativeStackDescriptor;
    previousDescriptor: NativeStackDescriptor | undefined;
    navigation: NativeStackNavigationHelpers;
    isFocused: boolean;
    isBeforeLast: boolean;
    isPopped: boolean;
    isDetached: boolean;
    hasNestedState: boolean;
    onRemovePoppedRoute: (key: string) => void;
    onNativeDismiss: (options: {
        key: string;
        markNativelyDismissed: boolean;
    }) => void;
    onNativeDismissPrevented: (key: string) => void;
};
export declare const CardScreen: React.MemoExoticComponent<({ descriptor, previousDescriptor, navigation, isFocused, isBeforeLast, isPopped, isDetached, hasNestedState, onRemovePoppedRoute, onNativeDismiss, onNativeDismissPrevented, }: Props) => React.JSX.Element>;
export {};
//# sourceMappingURL=CardScreen.d.ts.map