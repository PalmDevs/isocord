export { NativeStackView } from '../../views/NativeStackView';
//# sourceMappingURL=NativeStackView.d.ts.map