import type { HeaderConfigOptions, HeaderConfigResult } from './useHeaderConfig';
export declare function useHeaderConfig({ options, hasCustomHeader, headerLeftElement, headerRightElement, headerTitleElement, tintColor, }: HeaderConfigOptions): HeaderConfigResult;
//# sourceMappingURL=useHeaderConfig.android.d.ts.map