import type { ParamListBase, Route, StackNavigationState } from '@react-navigation/native';
import * as React from 'react';
import type { NativeStackDescriptor, NativeStackDescriptorMap } from '../../types.js';
export declare const SUPPORTS_FORM_SHEET: boolean;
export type NativeStackViewState = {
    previous: {
        index: number;
        routes: Route<string>[];
        descriptors: NativeStackDescriptorMap;
    };
    renderedRoutes: Route<string>[];
    poppedByKey: Map<string, {
        descriptor: NativeStackDescriptor;
        previousDescriptor: NativeStackDescriptor | undefined;
    }>;
    nativelyDismissedRouteKeys: Set<string>;
};
export type NativeStackViewStateAction = {
    type: 'SYNC_STATE';
    index: number;
    routes: Route<string>[];
    descriptors: NativeStackDescriptorMap;
} | {
    type: 'SYNC_DESCRIPTORS';
    descriptors: NativeStackDescriptorMap;
} | {
    type: 'REMOVE_POPPED_ROUTE';
    key: string;
} | {
    type: 'ADD_NATIVELY_DISMISSED_ROUTES';
    keys: string[];
};
export declare function reducer(state: NativeStackViewState, action: NativeStackViewStateAction): NativeStackViewState;
export declare function useViewState({ state, descriptors, }: {
    state: StackNavigationState<ParamListBase>;
    descriptors: NativeStackDescriptorMap;
}): readonly [NativeStackViewState, React.ActionDispatch<[action: NativeStackViewStateAction]>];
//# sourceMappingURL=NativeStackViewState.d.ts.map