import * as React from 'react';
import type { NativeStackDescriptor, NativeStackNavigationHelpers } from '../../types.js';
type Props = {
    descriptor: NativeStackDescriptor;
    navigation: NativeStackNavigationHelpers;
    isFocused: boolean;
    isPopped: boolean;
    onRemovePoppedRoute: (key: string) => void;
    onNativeDismiss: (options: {
        key: string;
        markNativelyDismissed: boolean;
    }) => void;
    onNativeDismissPrevented: (key: string) => void;
};
export declare const SheetScreen: React.MemoExoticComponent<({ descriptor, navigation, isFocused, isPopped, onRemovePoppedRoute, onNativeDismiss, onNativeDismissPrevented, }: Props) => React.JSX.Element>;
export {};
//# sourceMappingURL=SheetScreen.d.ts.map