import type { HeaderConfigOptions, HeaderConfigResult } from './useHeaderConfig';
export declare function useHeaderConfig({ options, hasCustomHeader, headerLeftElement, headerRightElement, headerTitleElement, headerTitleText, canGoBack, tintColor, isRemovePrevented, }: HeaderConfigOptions): HeaderConfigResult;
//# sourceMappingURL=useHeaderConfig.ios.d.ts.map