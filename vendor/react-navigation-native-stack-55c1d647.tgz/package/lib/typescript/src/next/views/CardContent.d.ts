import { HeaderBackContext } from '@react-navigation/elements';
import { ActivityView } from '@react-navigation/elements/internal';
import * as React from 'react';
import { type ColorValue } from 'react-native';
import type { NativeStackDescriptor } from '../../types.js';
type Props = {
    descriptor: NativeStackDescriptor;
    headerBack: React.ContextType<typeof HeaderBackContext>;
    activityMode: React.ComponentProps<typeof ActivityView>['mode'] | 'unmounted';
    backgroundColor: ColorValue;
    headerBackgroundMode: 'native' | 'screen' | 'none';
};
export declare function CardContent({ descriptor, headerBack, activityMode, backgroundColor, headerBackgroundMode, }: Props): React.JSX.Element;
export {};
//# sourceMappingURL=CardContent.d.ts.map