import { type NavigatorTypeBagBase, type ParamListBase, type StackActionHelpers, type StackNavigationState } from '@react-navigation/native';
import * as React from 'react';
import type { NativeStackNavigationEventMap, NativeStackNavigationOptions, NativeStackNavigatorProps } from '../../types.js';
declare function NativeStackNavigator({ initialRouteName, routeNamesChangeBehavior, children, layout, screenListeners, screenOptions, screenLayout, router, ...rest }: NativeStackNavigatorProps): React.JSX.Element;
export interface NativeStackTypeBag extends NavigatorTypeBagBase {
    State: StackNavigationState<this['ParamList']>;
    ScreenOptions: NativeStackNavigationOptions;
    EventMap: NativeStackNavigationEventMap;
    ActionHelpers: StackActionHelpers<this['ParamList']>;
    Navigator: typeof NativeStackNavigator;
}
export declare const createNativeStackNavigator: import("@react-navigation/core").TypedNavigatorFactory<NativeStackTypeBag>;
export declare const createNativeStackScreen: import("@react-navigation/core").StaticScreenFactory<import("@react-navigation/core").NavigatorTypeBagFor<NativeStackTypeBag, ParamListBase>>;
export {};
//# sourceMappingURL=createNativeStackNavigator.d.ts.map