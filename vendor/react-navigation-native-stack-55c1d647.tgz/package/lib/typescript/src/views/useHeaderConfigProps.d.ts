import { type Route } from '@react-navigation/native';
import { type ScreenStackHeaderConfigProps } from 'react-native-screens';
import type { NativeStackNavigationOptions } from '../types.js';
type Props = NativeStackNavigationOptions & {
    headerHeight: number;
    headerBack: {
        title?: string | undefined;
        href: undefined;
    } | undefined;
    route: Route<string>;
};
export declare function useHeaderConfigProps({ headerBackIcon, headerBackButtonDisplayMode, headerBackButtonMenuEnabled, headerBackTitle, headerBackTitleStyle, headerBackVisible, headerShadowVisible, headerLargeStyle, headerLargeTitleEnabled, headerLargeTitleShadowVisible, headerLargeTitleStyle, headerBackground, headerLeft, headerLeftBackgroundVisible, headerRight, headerRightBackgroundVisible, headerShown, headerStyle, headerBlurEffect, headerTintColor, headerTitle, headerTitleAlign, headerTitleStyle, headerTransparent, headerSearchBarOptions, headerBack, route, title, unstable_headerInsets: headerInsets, unstable_headerLeftItems: headerLeftItems, unstable_headerRightItems: headerRightItems, }: Props): ScreenStackHeaderConfigProps;
export {};
//# sourceMappingURL=useHeaderConfigProps.d.ts.map