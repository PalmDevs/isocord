import type { Icon } from '@react-navigation/elements';
import type { DefaultNavigatorOptions, Descriptor, NavigationHelpers, NavigationProp, ParamListBase, Route, RouteProp, StackActionHelpers, StackNavigationState, StackRouterOptions, Theme } from '@react-navigation/native';
import * as React from 'react';
import type { ColorValue, StyleProp, TextStyle, ViewStyle } from 'react-native';
import type { ScreenProps, ScreenStackHeaderConfigProps, ScrollEdgeEffect, SearchBarProps } from 'react-native-screens';
export type NativeStackNavigationEventMap = {
    /**
     * Event which fires when a transition animation starts.
     */
    transitionStart: {
        data: {
            closing: boolean;
        };
    };
    /**
     * Event which fires when a transition animation ends.
     */
    transitionEnd: {
        data: {
            closing: boolean;
        };
    };
    /**
     * Event which fires when a swipe back is canceled on iOS.
     */
    gestureCancel: {
        data: undefined;
    };
    /**
     * Event which fires when screen is in sheet presentation & it's detent changes.
     *
     * In payload it caries two fields:
     *
     * * `index` - current detent index in the `sheetAllowedDetents` array,
     * * `stable` - on Android `false` value means that the user is dragging the sheet or it is settling; on iOS it is always `true`.
     */
    sheetDetentChange: {
        data: {
            index: number;
            stable: boolean;
        };
    };
};
export type NativeStackNavigationProp<ParamList extends ParamListBase, RouteName extends keyof ParamList = string> = NavigationProp<ParamList, RouteName, StackNavigationState<ParamList>, NativeStackNavigationOptions, NativeStackNavigationEventMap, StackActionHelpers<ParamList>>;
export type NativeStackScreenProps<ParamList extends ParamListBase, RouteName extends keyof ParamList = string> = {
    navigation: NativeStackNavigationProp<ParamList, RouteName>;
    route: RouteProp<ParamList, RouteName>;
};
export type NativeStackOptionsArgs<ParamList extends ParamListBase, RouteName extends keyof ParamList = keyof ParamList> = NativeStackScreenProps<ParamList, RouteName> & {
    theme: Theme;
};
export type NativeStackNavigationHelpers = NavigationHelpers<ParamListBase, StackNavigationState<ParamListBase>, NativeStackNavigationEventMap>;
export type NativeStackNavigationConfig = {};
export type NativeStackHeaderProps = {
    /**
     * Options for the back button.
     */
    back?: {
        /**
         * Title of the previous screen.
         */
        title: string | undefined;
        /**
         * The `href` to use for the anchor tag on web
         */
        href: string | undefined;
    } | undefined;
    /**
     * Options for the current screen.
     */
    options: NativeStackNavigationOptions;
    /**
     * Route object for the current screen.
     */
    route: Route<string>;
    /**
     * Navigation prop for the header.
     */
    navigation: NativeStackNavigationProp<ParamListBase>;
};
export type NativeStackHeaderItemProps = {
    /**
     * Tint color for the header.
     */
    tintColor?: ColorValue | undefined;
    /**
     * Whether it's possible to navigate back in stack.
     */
    canGoBack?: boolean | undefined;
};
export type NativeStackHeaderBackProps = NativeStackHeaderItemProps & {
    /**
     * Label text for the button. Usually the title of the previous screen.
     * By default, this is only shown on iOS 18.
     */
    label?: string | undefined;
    /**
     * The `href` to use for the anchor tag on web
     */
    href?: string | undefined;
};
/**
 * Controls how the header responds when the screen content scrolls.
 *
 * An expanded header displays its full height. A collapsed header displays
 * only the compact toolbar. The start of the content is usually its top.
 */
export type NativeStackHeaderScrollOptions = {
    /**
     * Keeps the header at its full height while the content scrolls.
     */
    enabled: false;
} | ({
    /**
     * Allows scrolling to collapse or hide the header.
     */
    enabled: true;
    /**
     * Whether the header automatically settles at its nearest expanded,
     * collapsed, or hidden position when scrolling ends.
     * When `false`, the header can remain partially collapsed.
     */
    snap?: boolean | undefined;
    /**
     * Whether collapsing stops at the compact toolbar height.
     * When `false`, the entire header can move off-screen.
     */
    exitUntilCollapsed?: boolean | undefined;
} & ({
    enterAlways?: false | undefined;
    enterAlwaysCollapsed?: false | undefined;
} | {
    /**
     * Whether the header starts expanding as soon as the user scrolls
     * toward the start of the content. When `false`, expansion starts
     * after the content reaches its start.
     */
    enterAlways: true;
    /**
     * Whether expansion before the content reaches its start is limited
     * to the compact toolbar height. The remaining header expands after
     * the content reaches its start.
     */
    enterAlwaysCollapsed?: boolean | undefined;
}));
/**
 * Options only supported by the experimental stack.
 */
export type NativeStackNextNavigationOptions = {
    /**
     * Tint color for the back button while it is pressed.
     *
     * @platform android
     */
    unstable_headerBackButtonTintColorPressed?: ColorValue | undefined;
    /**
     * Tint color for the back button while it is focused.
     *
     * @platform android
     */
    unstable_headerBackButtonTintColorFocused?: ColorValue | undefined;
    /**
     * Controls how a custom header background behaves as the app bar collapses.
     *
     * @platform android
     */
    unstable_headerBackgroundCollapseMode?: 'off' | 'parallax' | undefined;
    /**
     * Subtitle displayed below the large title.
     *
     * @platform ios 26+
     */
    unstable_headerLargeSubtitle?: string | ((props: {
        tintColor?: ColorValue | undefined;
    }) => React.ReactNode) | undefined;
    /**
     * String or React element displayed as the header subtitle.
     *
     * A string is supported on Android and iOS 26+.
     * A function that returns a React element is only supported on iOS 26+.
     *
     * @platform android, ios 26+
     */
    unstable_headerSubtitle?: string | ((props: {
        tintColor?: ColorValue | undefined;
    }) => React.ReactNode) | undefined;
    /**
     * Material app bar size.
     *
     * @platform android
     */
    unstable_headerType?: 'small' | 'medium' | 'large' | undefined;
    /**
     * Scroll behavior configuration for the app bar.
     * Defaults to disabled for a small header and enabled for medium and large headers.
     *
     * @platform android
     */
    unstable_headerScroll?: NativeStackHeaderScrollOptions | undefined;
    /**
     * Native Android toolbar menu configuration.
     *
     * This is an unstable API and might change in the future.
     *
     * @platform android
     */
    unstable_headerToolbarMenu?: NativeStackHeaderToolbarMenu | undefined;
    /**
     * Whether native Android toolbar menu groups display dividers.
     *
     * This is an unstable API and might change in the future.
     *
     * @platform android
     */
    unstable_headerToolbarMenuGroupDividerEnabled?: boolean | undefined;
};
export type NativeStackNavigationOptions = {
    /**
     * String that can be displayed in the header as a fallback for `headerTitle`.
     */
    title?: string | undefined;
    /**
     * Function that given `HeaderProps` returns a React Element to display as a header.
     */
    header?: ((props: NativeStackHeaderProps) => React.ReactNode) | undefined;
    /**
     * Whether the back button is visible in the header.
     * You can use it to show a back button alongside `headerLeft` if you have specified it.
     *
     * This will have no effect on the first screen in the stack.
     */
    headerBackVisible?: boolean | undefined;
    /**
     * Title string used by the back button on iOS.
     * Defaults to the previous scene's title.
     * On iOS the text might be shortened to "Back" or arrow icon depending on the available space, following native iOS behaviour.
     * See `headerBackButtonDisplayMode` to read about limitations and interactions with other props.
     * Use `headerBackButtonDisplayMode: "minimal"` to hide it.
     *
     * Only supported on iOS and Web.
     *
     * @platform ios, web
     */
    headerBackTitle?: string | undefined;
    /**
     * Style object for header back title. Supported properties:
     * - fontFamily
     * - fontSize
     *
     * Only supported on iOS and Web.
     *
     * @platform ios, web
     */
    headerBackTitleStyle?: StyleProp<{
        fontFamily?: string | undefined;
        fontSize?: number | undefined;
    }> | undefined;
    /**
     * Icon to display in the header in the back button.
     *
     * Supported types:
     * - image: custom image source
     * - sfSymbol: SF Symbol icon (iOS only - when using custom header)
     * - materialSymbol: material symbol icon (Android only)
     *
     * Defaults to back icon image for the platform
     * - A chevron on iOS
     * - An arrow on Android
     *
     * @example
     * ```js
     * headerBackIcon: {
     *   type: 'image',
     *   source: require('./back-icon.png'),
     * }
     * ```
     */
    headerBackIcon?: Icon | undefined;
    /**
     * Style of the header when a large title is shown.
     * The large title is shown if `headerLargeTitleEnabled` is `true` and
     * the edge of any scrollable content reaches the matching edge of the header.
     *
     * Supported properties:
     * - backgroundColor
     *
     * Only supported on iOS.
     *
     * @platform ios
     */
    headerLargeStyle?: StyleProp<{
        backgroundColor?: ColorValue | undefined;
    }> | undefined;
    /**
     * Whether to enable header with large title which collapses to regular header on scroll.
     *
     * For large title to collapse on scroll, the content of the screen should be wrapped in a scrollable view such as `ScrollView` or `FlatList`.
     * If the scrollable area doesn't fill the screen, the large title won't collapse on scroll.
     * You also need to specify `contentInsetAdjustmentBehavior="automatic"` in your `ScrollView`, `FlatList` etc.
     *
     * Only supported on iOS.
     *
     * @platform ios
     */
    headerLargeTitleEnabled?: boolean | undefined;
    /**
     * Whether drop shadow of header is visible when a large title is shown.
     *
     * Only supported on iOS.
     *
     * @platform ios
     */
    headerLargeTitleShadowVisible?: boolean | undefined;
    /**
     * Style object for large title in header. Supported properties:
     * - fontFamily
     * - fontSize
     * - fontWeight
     * - color
     *
     * Only supported on iOS.
     * In the experimental stack, it's also used on Android for the expanded title of `medium` and `large` headers.
     *
     * @platform ios
     */
    headerLargeTitleStyle?: StyleProp<Pick<TextStyle, 'fontFamily' | 'fontSize' | 'fontWeight' | 'color'>> | undefined;
    /**
     * Whether to show the header. The header is shown by default.
     * Setting this to `false` hides the header.
     */
    headerShown?: boolean | undefined;
    /**
     * Style object for header. Supported properties:
     * - backgroundColor
     */
    headerStyle?: StyleProp<{
        backgroundColor?: ColorValue | undefined;
    }> | undefined;
    /**
     * Whether to hide the elevation shadow (Android) or the bottom border (iOS) on the header.
     */
    headerShadowVisible?: boolean | undefined;
    /**
     * Boolean indicating whether the navigation bar is translucent.
     * Setting this to `true` makes the header absolutely positioned,
     * and changes the background color to `transparent` unless specified in `headerStyle`.
     * On Android, enabling this disables header scrolling and collapsing, so
     * `unstable_headerScroll` has no effect.
     *
     * In the experimental stack on iOS, the content is currently always rendered under the native header,
     * so setting this to `false` doesn't move the content below it.
     */
    headerTransparent?: boolean | undefined;
    /**
     * Blur effect for the translucent header.
     * The `headerTransparent` option needs to be set to `true` for this to work.
     *
     * **Note:** Using both `headerBlurEffect` and `scrollEdgeEffects` (>= iOS 26) simultaneously may cause overlapping effects.
     *
     * Only supported on iOS.
     *
     * @platform ios
     */
    headerBlurEffect?: ScreenStackHeaderConfigProps['blurEffect'] | undefined;
    /**
     * Tint color for the header. Changes the color of back button and title.
     */
    headerTintColor?: ColorValue | undefined;
    /**
     * Function which returns a React Element to render as the background of the header.
     * This is useful for using backgrounds such as an image, a gradient, blur effect etc.
     * You can use this with `headerTransparent` to render content underneath a translucent header.
     * On Android, this is ignored for a small header when header scrolling is enabled.
     */
    headerBackground?: (() => React.ReactNode) | undefined;
    /**
     * Function which returns a React Element to display on the left side of the header.
     * This replaces the back button. See `headerBackVisible` to show the back button alongside the left element.
     * Will be overridden by `headerLeftItems` on iOS.
     */
    headerLeft?: ((props: NativeStackHeaderBackProps) => React.ReactNode) | undefined;
    /**
     * Whether the liquid glass background is visible for the item.
     *
     * Only supported on iOS 26.0 and later.
     * Older versions of iOS and other platforms never show the background.
     *
     * Defaults to `true`.
     */
    headerLeftBackgroundVisible?: boolean | undefined;
    /**
     * Function which returns a React Element to display on the right side of the header.
     * Will be overridden by `headerRightItems` on iOS.
     */
    headerRight?: ((props: NativeStackHeaderItemProps) => React.ReactNode) | undefined;
    /**
     * Whether the liquid glass background is visible for the item.
     *
     * Only supported on iOS 26.0 and later.
     * Older versions of iOS and other platforms never show the background.
     *
     * Defaults to `true`.
     */
    headerRightBackgroundVisible?: boolean | undefined;
    /**
     * Function which returns an array of items to display as on the left side of the header.
     * Overrides `headerLeft`.
     *
     * This is an unstable API and might change in the future.
     *
     * @platform ios
     */
    unstable_headerLeftItems?: ((props: NativeStackHeaderItemProps) => NativeStackHeaderItem[]) | undefined;
    /**
     * Function which returns an array of items to display as on the right side of the header.
     * Overrides `headerRight`.
     *
     * This is an unstable API and might change in the future.
     *
     * @platform ios
     */
    unstable_headerRightItems?: ((props: NativeStackHeaderItemProps) => NativeStackHeaderItem[]) | undefined;
    /**
     * String or a function that returns a React Element to be used by the header.
     * Defaults to screen `title` or route name.
     *
     * When a function is passed, it receives `tintColor` and`children` in the options object as an argument.
     * The title string is passed in `children`.
     *
     * Note that if you render a custom element by passing a function, animations for the title won't work.
     */
    headerTitle?: string | ((props: {
        /**
         * The title text of the header.
         */
        children: string;
        /**
         * Tint color for the header.
         */
        tintColor?: ColorValue | undefined;
    }) => React.ReactNode) | undefined;
    /**
     * How to align the header title.
     * Defaults to `left` on platforms other than iOS.
     *
     * Not supported on iOS. It's always `center` on iOS and cannot be changed.
     *
     * In the experimental stack on Android, it only applies to the `small` header type.
     */
    headerTitleAlign?: 'left' | 'center' | undefined;
    /**
     * Style object for header title. Supported properties:
     * - fontFamily
     * - fontSize
     * - fontWeight
     * - color
     */
    headerTitleStyle?: StyleProp<Pick<TextStyle, 'fontFamily' | 'fontSize' | 'fontWeight' | 'color'>> | undefined;
    /**
     * Options to render a native search bar.
     * You also need to specify `contentInsetAdjustmentBehavior="automatic"` in your `ScrollView`, `FlatList` etc.
     * If you don't have a `ScrollView`, specify `headerTransparent: false`.
     */
    headerSearchBarOptions?: (Omit<SearchBarProps, 'onChangeText'> & {
        onChange?: SearchBarProps['onChangeText'] | undefined;
    }) | undefined;
    /**
     * Boolean indicating whether to show the menu on longPress of iOS >= 14 back button. Defaults to `true`.
     * Requires `react-native-screens` version >=3.3.0.
     *
     * Only supported on iOS.
     *
     * @platform ios
     */
    headerBackButtonMenuEnabled?: boolean | undefined;
    /**
     * How the back button displays icon and title.
     *
     * Supported values:
     * - "default" - Displays one of the following depending on the available space: previous screen's title, generic title (e.g. 'Back') or no title (only icon).
     * - "generic" – Displays one of the following depending on the available space: generic title (e.g. 'Back') or no title (only icon).
     * - "minimal" – Always displays only the icon without a title.
     *
     * The space-aware behavior is disabled when:
     * - The iOS version is 13 or lower
     * - Custom font family or size is set (e.g. with `headerBackTitleStyle`)
     * - Back button menu is disabled (e.g. with `headerBackButtonMenuEnabled`)
     *
     * In such cases, a static title and icon are always displayed.
     *
     * Defaults to "default" on iOS, and "minimal" on other platforms.
     *
     * Only supported on iOS and Web.
     *
     * @platform ios, web
     */
    headerBackButtonDisplayMode?: ScreenStackHeaderConfigProps['backButtonDisplayMode'] | undefined;
    /**
     * Option to control which edges of the native header should apply window insets.
     *
     * By default, the native header applies window insets to all edges.
     * Setting an edge to `false` disables its inset for this header and any nested headers.
     *
     * A nested header cannot re-enable an inset disabled by a parent,
     * even by setting the edge to `true`.
     *
     * This is an unstable API and might change in the future.
     *
     * @platform android
     */
    unstable_headerInsets?: {
        top?: boolean | undefined;
        left?: boolean | undefined;
        right?: boolean | undefined;
        bottom?: boolean | undefined;
    } | undefined;
    /**
     * Whether the home indicator should prefer to stay hidden on this screen. Defaults to `false`.
     *
     * @platform ios
     */
    autoHideHomeIndicator?: boolean | undefined;
    /**
     * Whether the keyboard should hide when swiping to the previous screen. Defaults to `false`.
     *
     * @platform ios
     */
    keyboardHandlingEnabled?: boolean | undefined;
    /**
     * Sets the visibility of the navigation bar. Defaults to `false`.
     *
     * @platform android
     */
    navigationBarHidden?: boolean | undefined;
    /**
     * Sets the status bar animation (similar to the `StatusBar` component).
     * On Android, setting either `fade` or `slide` will set the transition of status bar color. On iOS, this option applies to appearance animation of the status bar.
     * Requires setting `View controller-based status bar appearance -> YES` (or removing the config) in your `Info.plist` file.
     *
     * Defaults to `fade` on iOS and `none` on Android.
     *
     * Only supported on Android and iOS.
     *
     * @platform android, ios
     */
    statusBarAnimation?: ScreenProps['statusBarAnimation'] | undefined;
    /**
     * Whether the status bar should be hidden on this screen.
     * Requires setting `View controller-based status bar appearance -> YES` in your Info.plist file.
     *
     * Only supported on Android and iOS.
     *
     * @platform android, ios
     */
    statusBarHidden?: boolean | undefined;
    /**
     * Sets the status bar color (similar to the `StatusBar` component).
     * Requires setting `View controller-based status bar appearance -> YES` (or removing the config) in your `Info.plist` file.
     * `auto` and `inverted` are supported only on iOS. On Android, they will fallback to `light`.
     *
     * Defaults to `auto` on iOS and `light` on Android.
     *
     * Only supported on Android and iOS.
     *
     * @platform android, ios
     */
    statusBarStyle?: ScreenProps['statusBarStyle'] | undefined;
    /**
     * Sets the direction in which you should swipe to dismiss the screen.
     * When using `vertical` option, options `fullScreenGestureEnabled: true`, `animationMatchesGesture: true` and `animation: 'slide_from_bottom'` are set by default.
     *
     * Supported values:
     * - `vertical` – dismiss screen vertically
     * - `horizontal` – dismiss screen horizontally (default)
     *
     * @platform ios
     */
    gestureDirection?: ScreenProps['swipeDirection'] | undefined;
    /**
     * Style object for the scene content.
     */
    contentStyle?: StyleProp<ViewStyle> | undefined;
    /**
     * Whether the gesture to dismiss should use animation provided to `animation` prop. Defaults to `false`.
     *
     * Doesn't affect the behavior of screens presented modally.
     *
     * @platform ios
     */
    animationMatchesGesture?: boolean | undefined;
    /**
     * Whether the gesture to dismiss should work on the whole screen. The behavior depends on iOS version.
     *
     * On iOS 18 and below:
     * `false` by default. If enabled, swipe gesture will use `simple_push` transition animation by default. It can be changed
     * with `animation` & `animationMatchesGesture` props, but default iOS swipe animation is not achievable.
     *
     * On iOS 26 and up:
     * `true` by default to match new native behavior. You can still customize it with `animation` & `animationMatchesGesture` props.
     *
     * Doesn't affect the behavior of screens presented modally.
     *
     * @platform ios
     */
    fullScreenGestureEnabled?: boolean | undefined;
    /**
     * iOS 18 and below. Controls whether the full screen dismiss gesture has shadow under view during transition.
     * The gesture uses custom transition and thus doesn't have a shadow by default. When enabled, a custom shadow view
     * is added during the transition which tries to mimic the default iOS shadow. Defaults to `true`.
     *
     * This does not affect the behavior of transitions that don't use gestures, enabled by `fullScreenGestureEnabled` prop.
     *
     * @deprecated since iOS 26.
     *
     * @platform ios
     */
    fullScreenGestureShadowEnabled?: boolean | undefined;
    /**
     * Whether you can use gestures to dismiss this screen. Defaults to `true`.
     *
     * Only supported on iOS.
     *
     * @platform ios
     */
    gestureEnabled?: boolean | undefined;
    /**
     * Use it to restrict the distance from the edges of screen in which the gesture should be recognized. To be used alongside `fullScreenGestureEnabled`.
     *
     * @platform ios
     */
    gestureResponseDistance?: ScreenProps['gestureResponseDistance'] | undefined;
    /**
     * The type of animation to use when this screen replaces another screen. Defaults to `push`.
     *
     * Supported values:
     * - "push": the new screen will perform push animation.
     * - "pop": the new screen will perform pop animation.
     *
     * Only supported on iOS and Android.
     */
    animationTypeForReplace?: ScreenProps['replaceAnimation'] | undefined;
    /**
     * How the screen should animate when pushed or popped.
     *
     * Supported values:
     * - "default": use the platform default animation
     * - "fade": fade screen in or out
     * - "fade_from_bottom" – performs a fade from bottom animation
     * - "flip": flip the screen, requires presentation: "modal" (iOS only)
     * - "simple_push": use the platform default animation, but without shadow and native header transition (iOS only)
     * - "slide_from_bottom": slide in the new screen from bottom
     * - "slide_from_right": slide in the new screen from right (Android only, uses default animation on iOS)
     * - "slide_from_left": slide in the new screen from left (Android only, uses default animation on iOS)
     * - "ios_from_right" - iOS like slide in animation. pushes in the new screen from right to left (Android only, resolves to default transition on iOS)
     * - "ios_from_left" - iOS like slide in animation. pushes in the new screen from left to right (Android only, resolves to default transition on iOS)
     * - "none": don't animate the screen
     *
     * Only supported on iOS and Android.
     *
     * In the experimental stack, it's only supported on Android,
     * and `flip` and `simple_push` aren't supported.
     */
    animation?: ScreenProps['stackAnimation'] | undefined;
    /**
     * Duration (in milliseconds) for the following transition animations on iOS:
     * - `slide_from_bottom`
     * - `fade_from_bottom`
     * - `fade`
     * - `simple_push`
     *
     * Defaults to `500`.
     *
     * The duration is not customizable for:
     * - Screens with `default` and `flip` animations
     * - Screens with `presentation` set to `modal`, `formSheet`, `pageSheet` (regardless of animation)
     *
     * In the experimental stack, it's only supported on Android,
     * for all animations except `default` and `none`.
     *
     * @platform ios
     */
    animationDuration?: number | undefined;
    /**
     * How should the screen be presented.
     *
     * Supported values:
     * - "card": the new screen will be pushed onto a stack, which means the default animation will be slide from the side on iOS, the animation on Android will vary depending on the OS version and theme.
     * - "modal": the new screen will be presented modally. this also allows for a nested stack to be rendered inside the screen.
     * - "transparentModal": the new screen will be presented modally, but in addition, the previous screen will stay so that the content below can still be seen if the screen has translucent background.
     * - "containedModal": will use "UIModalPresentationCurrentContext" modal style on iOS and will fallback to "modal" on Android.
     * - "containedTransparentModal": will use "UIModalPresentationOverCurrentContext" modal style on iOS and will fallback to "transparentModal" on Android.
     * - "fullScreenModal": will use "UIModalPresentationFullScreen" modal style on iOS and will fallback to "modal" on Android.
     * - "formSheet": will use "UIModalPresentationFormSheet" modal style on iOS and a bottom sheet on Android.
     * - "pageSheet": will use "UIModalPresentationPageSheet" modal style on iOS and will fallback to "modal" on Android.
     *
     * Only supported on iOS and Android.
     */
    presentation?: Exclude<ScreenProps['stackPresentation'], 'push'> | 'card' | undefined;
    /**
     * Describes heights where a sheet can rest.
     * Works only when `presentation` is set to `formSheet`.
     *
     * Heights should be described as fraction (a number from `[0, 1]` interval) of screen height / maximum detent height.
     * You can pass an array of ascending values each defining allowed sheet detent. iOS accepts any number of detents,
     * while **Android is limited to three**.
     *
     * There is also possibility to specify `fitToContents` literal, which intents to set the sheet height
     * to the height of its contents.
     *
     * Note that the array **must** be sorted in ascending order. This invariant is verified only in development mode,
     * where violation results in error.
     *
     * **Android is limited to up 3 values in the array** -- any surplus values, beside first three are ignored.
     *
     * Defaults to `[1.0]`.
     */
    sheetAllowedDetents?: number[] | 'fitToContents' | undefined;
    /**
     * Integer value describing elevation of the sheet, impacting shadow on the top edge of the sheet.
     *
     * Not dynamic - changing it after the component is rendered won't have an effect.
     *
     * Defaults to `24`.
     *
     * @platform Android
     */
    sheetElevation?: number | undefined;
    /**
     * Whether the sheet should expand to larger detent when scrolling.
     * Works only when `presentation` is set to `formSheet`.
     * Defaults to `true`.
     *
     * @platform ios
     */
    sheetExpandsWhenScrolledToEdge?: boolean | undefined;
    /**
     * The corner radius that the sheet will try to render with.
     * Works only when `presentation` is set to `formSheet`.
     *
     * If set to non-negative value it will try to render sheet with provided radius, else it will apply system default.
     *
     * If left unset system default is used.
     */
    sheetCornerRadius?: number | undefined;
    /**
     * Index of the detent the sheet should expand to after being opened.
     * Works only when `stackPresentation` is set to `formSheet`.
     *
     * If the specified index is out of bounds of `sheetAllowedDetents` array, in dev environment more error will be thrown,
     * in production the value will be reset to default value.
     *
     * Additionaly there is `last` value available, when set the sheet will expand initially to last (largest) detent.
     *
     * Defaults to `0` - which represents first detent in the detents array.
     */
    sheetInitialDetentIndex?: number | 'last' | undefined;
    /**
     * Boolean indicating whether the sheet shows a grabber at the top.
     * Works only when `presentation` is set to `formSheet`.
     * Defaults to `false`.
     *
     * @platform ios
     */
    sheetGrabberVisible?: boolean | undefined;
    /**
     * The largest sheet detent for which a view underneath won't be dimmed.
     * Works only when `presentation` is set to `formSheet`.
     *
     * This prop can be set to a number, which indicates index of detent in `sheetAllowedDetents` array for which
     * there won't be a dimming view beneath the sheet.
     *
     * Additionaly there are following options available:
     *
     * * `none` - there will be dimming view for all detents levels,
     * * `last` - there won't be a dimming view for any detent level.
     *
     * @remark
     * On iOS, the native implementation might resize the sheet w/o explicitly changing the detent level, e.g. in case of keyboard appearance.
     * In case after such resize the sheet exceeds height for which in regular scenario a dimming view would be applied - it will be applied,
     * even if the detent has not effectively been changed.
     *
     * Defaults to `none`, indicating that the dimming view should be always present.
     */
    sheetLargestUndimmedDetentIndex?: number | 'none' | 'last' | undefined;
    /**
     * Whether the sheet content should be rendered behind the Status Bar or display cutouts.
     *
     * When set to `true`, the sheet will extend to the physical edges of the stack,
     * allowing content to be visible behind the status bar or display cutouts.
     * Detent ratios in sheetAllowedDetents will be measured relative to the full stack height.
     *
     * When set to `false`, the sheet's layout will be constrained by the inset from the top
     * and the detent ratios will then be measured relative to the adjusted height (excluding the top inset).
     * This means that sheetAllowedDetents will result in different sheet heights depending on this prop.
     *
     * Defaults to `false`.
     *
     * @platform android
     */
    sheetShouldOverflowTopInset?: boolean | undefined;
    /**
     * Whether the default native animation should be used when the sheet's with
     * `fitToContents` content size changes.
     *
     * When set to `true`, the sheet uses internal logic to synchronize size updates and
     * translation animations during entry, exit, or content updates. This ensures a smooth
     * transition for standard, static content mounting/unmounting.
     *
     * When set to `false`, the internal animation and translation logic is ignored. This
     * allows the sheet to adjust its size dynamically based on the current dimensions of
     * the content provided by the developer, allowing implementing custom resizing animations.
     *
     * Defaults to `true`.
     *
     * @platform android
     */
    sheetResizeAnimationEnabled?: boolean | undefined;
    /**
     * The display orientation to use for the screen.
     *
     * Supported values:
     * - "default" - resolves to "all" without "portrait_down" on iOS. On Android, this lets the system decide the best orientation.
     * - "all": all orientations are permitted.
     * - "portrait": portrait orientations are permitted.
     * - "portrait_up": right-side portrait orientation is permitted.
     * - "portrait_down": upside-down portrait orientation is permitted.
     * - "landscape": landscape orientations are permitted.
     * - "landscape_left": landscape-left orientation is permitted.
     * - "landscape_right": landscape-right orientation is permitted.
     *
     * If not set, the screen inherits the orientation of its parent screen.
     * If no parent screen sets the `orientation`, it uses the supported orientations in the app's `Info.plist` on iOS,
     * on Android, it lets the system decide the best orientation.
     *
     * Only supported on iOS and Android.
     */
    orientation?: ScreenProps['screenOrientation'] | undefined;
    /**
     * Configures the scroll edge effect for the _content ScrollView_ (the ScrollView that is present in first descendants chain of the Screen).
     * Depending on values set, it will blur the scrolling content below certain UI elements (header items, search bar)
     * for the specified edge of the ScrollView.
     *
     * When set in nested containers, i.e. Native Stack inside Native Bottom Tabs, or the other way around,
     * the ScrollView will use only the innermost one's config.
     *
     * **Note:** Using both `headerBlurEffect` and `scrollEdgeEffects` (>= iOS 26) simultaneously may cause overlapping effects.
     *
     * Edge effects can be configured for each edge separately. The following values are currently supported:
     *
     * - `automatic` - the automatic scroll edge effect style,
     * - `hard` - a scroll edge effect with a hard cutoff and dividing line,
     * - `soft` - a soft-edged scroll edge effect,
     * - `hidden` - no scroll edge effect.
     *
     * Defaults to `automatic` for each edge.
     *
     * @platform ios
     *
     * @supported iOS 26 or higher
     */
    scrollEdgeEffects?: {
        bottom?: ScrollEdgeEffect | undefined;
        left?: ScrollEdgeEffect | undefined;
        right?: ScrollEdgeEffect | undefined;
        top?: ScrollEdgeEffect | undefined;
    } | undefined;
    /**
     * Footer component that can be used alongside formSheet stack presentation style.
     *
     * This option is provided, because due to implementation details it might be problematic
     * to implement such layout with JS-only code.
     *
     * Note that this prop is marked as unstable and might be subject of breaking changes,
     * including removal, in particular when we find solution that will make implementing it with JS
     * straightforward.
     *
     * @platform android
     */
    unstable_sheetFooter?: (() => React.ReactNode) | undefined;
    /**
     * What should happen when screens become inactive.
     * - `pause`: Effects are cleaned up.
     * - `unmount`: Screen is unmounted
     * - `none`: Screen renders normally
     *
     * Defaults to `pause`.
     *
     * Preloaded screens won't be paused until after navigated to.
     * This makes sure that effects are run to initialize the screen.
     *
     * Screens with nested navigators and last 2 screens won't be unmounted.
     */
    inactiveBehavior?: 'pause' | 'unmount' | 'none' | undefined;
} & NativeStackNextNavigationOptions;
type IconIOS = Extract<Icon, {
    type: 'image';
}> | Omit<Extract<Icon, {
    type: 'sfSymbol';
}>, 'renderingMode'>;
type SharedHeaderItem = {
    /**
     * Label of the item.
     */
    label: string;
    /**
     * Style for the item label.
     */
    labelStyle?: {
        fontFamily?: string | undefined;
        fontSize?: number | undefined;
        fontWeight?: string | undefined;
        color?: ColorValue | undefined;
    } | undefined;
    /**
     * Icon for the item
     */
    icon?: IconIOS | undefined;
    /**
     * The variant of the item.
     * "prominent" only available from iOS 26.0 and later.
     *
     * "done" isn't supported in the experimental stack.
     *
     * Read more: https://developer.apple.com/documentation/uikit/uibarbuttonitem/style-swift.property
     */
    variant?: 'plain' | 'done' | 'prominent' | undefined;
    /**
     * The tint color to apply to the item.
     *
     * Read more: https://developer.apple.com/documentation/uikit/uibarbuttonitem/tintcolor
     */
    tintColor?: ColorValue | undefined;
    /**
     * Whether the item is in a disabled state.
     */
    disabled?: boolean | undefined;
    /**
     * The width of the item.
     *
     * Read more: https://developer.apple.com/documentation/uikit/uibarbuttonitem/width
     */
    width?: number | undefined;
    /**
     * Whether the background this item may share with other items in the bar should be hidden.
     * Only available from iOS 26.0 and later.
     *
     * Read more: https://developer.apple.com/documentation/uikit/uibarbuttonitem/hidessharedbackground
     */
    hidesSharedBackground?: boolean | undefined;
    /**
     * Whether this item can share a background with other items.
     * Only available from iOS 26.0 and later.
     *
     * Read more: https://developer.apple.com/documentation/uikit/uibarbuttonitem/sharesbackground
     */
    sharesBackground?: boolean | undefined;
    /**
     * An identifier used to match items across transitions.
     * Only available from iOS 26.0 and later.
     *
     * Read more: https://developer.apple.com/documentation/uikit/uibarbuttonitem/identifier
     */
    identifier?: string | undefined;
    /**
     * Priority used when the items don't fit in the header.
     * Items with lower priority are moved to the overflow menu first.
     *
     * Only applies to items in `unstable_headerRightItems`.
     *
     * Defaults to `default`.
     * Only available from iOS 27.0 and later.
     *
     * Read more: https://developer.apple.com/documentation/uikit/uibarbuttonitemvisibilitypriority
     */
    visibilityPriority?: 'low' | 'default' | 'high' | undefined;
    /**
     * A badge to display on a item.
     * Only available from iOS 26.0 and later.
     *
     * Read more: https://developer.apple.com/documentation/uikit/uibarbuttonitembadge
     */
    badge?: {
        /**
         * The text to display in the badge.
         */
        value: number | string;
        /**
         * Style of the badge.
         */
        style?: {
            color?: ColorValue | undefined;
            backgroundColor?: ColorValue | undefined;
            fontFamily?: string | undefined;
            fontSize?: number | undefined;
            fontWeight?: string | undefined;
        } | undefined;
    } | undefined;
    /**
     * Accessibility label for the item.
     */
    accessibilityLabel?: string | undefined;
    /**
     * Accessibility hint for the item.
     */
    accessibilityHint?: string | undefined;
};
/**
 * A button item in the header.
 */
export type NativeStackHeaderItemButton = SharedHeaderItem & {
    /**
     * Type of the item.
     */
    type: 'button';
    /**
     * Function to call when the item is pressed.
     */
    onPress: () => void;
    /**
     * Whether the item is in a selected state.
     *
     * Read more: https://developer.apple.com/documentation/uikit/uibarbuttonitem/isselected
     */
    selected?: boolean | undefined;
};
/**
 * Options only mapped for menu actions by the experimental stack.
 */
export type NativeStackNextHeaderItemMenuAction = {
    /**
     * Unique identifier for the menu item.
     */
    identifier?: string | undefined;
};
/**
 * An action item in a menu.
 */
export type NativeStackHeaderItemMenuAction = {
    type: 'action';
    /**
     * Label for the menu item.
     */
    label: string;
    /**
     * The secondary text displayed alongside the label of the menu item.
     *
     * Not supported in the experimental stack.
     */
    description?: string | undefined;
    /**
     * Icon for the menu item.
     */
    icon?: IconIOS | undefined;
    /**
     * Function to call when the menu item is pressed.
     */
    onPress: () => void;
    /**
     * The state of an action- or command-based menu item.
     *
     * Not supported in the experimental stack.
     * Use items with `type: 'toggle'` instead.
     *
     * Read more: https://developer.apple.com/documentation/uikit/uimenuelement/state
     */
    state?: 'on' | 'off' | 'mixed' | undefined;
    /**
     * Whether to apply disabled style to the item.
     *
     * Not supported in the experimental stack.
     *
     * Read more: https://developer.apple.com/documentation/uikit/uimenuelement/attributes/disabled
     */
    disabled?: boolean | undefined;
    /**
     * Whether to apply destructive style to the item.
     *
     * Not supported in the experimental stack.
     *
     * Read more: https://developer.apple.com/documentation/uikit/uimenuelement/attributes/destructive
     */
    destructive?: boolean | undefined;
    /**
     * Whether to apply hidden style to the item.
     *
     * Not supported in the experimental stack.
     *
     * Read more: https://developer.apple.com/documentation/uikit/uimenuelement/attributes/hidden
     */
    hidden?: boolean | undefined;
    /**
     * Whether to keep the menu presented after firing the element's action.
     *
     * Read more: https://developer.apple.com/documentation/uikit/uimenuelement/attributes/keepsmenupresented
     */
    keepsMenuPresented?: boolean | undefined;
    /**
     * An elaborated title that explains the purpose of the action.
     *
     * On iOS, the system displays this title in the discoverability heads-up display (HUD).
     * If this is not set, the HUD displays the title property.
     *
     * Not supported in the experimental stack.
     *
     * Read more: https://developer.apple.com/documentation/uikit/uiaction/discoverabilitytitle
     */
    discoverabilityLabel?: string | undefined;
} & NativeStackNextHeaderItemMenuAction;
/**
 * An item in a menu that can be checked and unchecked by the user.
 */
export type NativeStackHeaderItemMenuToggle = Omit<NativeStackHeaderItemMenuAction, 'type' | 'identifier' | 'onPress' | 'state'> & {
    type: 'toggle';
    /**
     * Unique identifier for the menu item.
     * Used as the key in the `checked` object passed to `onChange` of the menu.
     */
    identifier: string;
    /**
     * Whether the item is checked when the menu is first shown.
     *
     * Defaults to `false`.
     */
    defaultChecked?: boolean | undefined;
};
/**
 * Event passed to `onChange` of a header menu or a toolbar menu group.
 */
export type NativeStackHeaderMenuChangeEvent = {
    /**
     * Checked state of the toggle items in the menu, by their `identifier`.
     */
    checked: Record<string, boolean>;
};
/**
 * Options only mapped for submenus by the experimental stack.
 */
export type NativeStackNextHeaderItemMenuSubmenu = {
    /**
     * Unique identifier for the submenu.
     */
    identifier?: string | undefined;
};
/**
 * A submenu item that contains other menu items.
 */
export type NativeStackHeaderItemMenuSubmenu = {
    type: 'submenu';
    /**
     * Label for the submenu item.
     */
    label: string;
    /**
     * The secondary text displayed alongside the label of the submenu item.
     *
     * Not supported in the experimental stack.
     */
    description?: string | undefined;
    /**
     * Icon for the submenu item.
     */
    icon?: IconIOS | undefined;
    /**
     * Whether the menu is displayed inline with the parent menu.
     * By default, submenus are displayed after expanding the parent menu item.
     * Inline menus are displayed as part of the parent menu as a section.
     *
     * Defaults to `false`.
     *
     * Read more: https://developer.apple.com/documentation/uikit/uimenu/options-swift.struct/displayinline
     */
    inline?: boolean | undefined;
    /**
     * How the submenu items are displayed.
     * - `default`: menu items are displayed normally.
     * - `palette`: menu items are displayed in a horizontal row.
     *
     * Defaults to `default`.
     *
     * Read more: https://developer.apple.com/documentation/uikit/uimenu/options-swift.struct/displayaspalette
     */
    layout?: 'default' | 'palette' | undefined;
    /**
     * Whether to apply destructive style to the menu item.
     *
     * Not supported in the experimental stack.
     *
     * Read more: https://developer.apple.com/documentation/uikit/uimenuelement/attributes/destructive
     */
    destructive?: boolean | undefined;
    /**
     * Whether multiple items in the submenu can be selected, i.e. in "on" state.
     *
     * Defaults to `true`.
     *
     * Read more: https://developer.apple.com/documentation/uikit/uimenu/options-swift.struct/singleselection
     */
    multiselectable?: boolean | undefined;
    /**
     * Function called when the user checks or unchecks toggle items in the menu.
     *
     * In a single selection menu, i.e. `multiselectable: false`,
     * toggle items in nested submenus are part of the same selection.
     * So it also receives them, and `onChange` of the nested submenus isn't called.
     */
    onChange?: ((event: NativeStackHeaderMenuChangeEvent) => void) | undefined;
    /**
     * Array of menu items (actions, toggles or submenus).
     */
    items: NativeStackHeaderItemMenu['menu']['items'];
} & NativeStackNextHeaderItemMenuSubmenu;
/**
 * Options only mapped for menus by the experimental stack.
 */
export type NativeStackNextHeaderItemMenuOptions = {
    /**
     * Unique identifier for the menu.
     */
    identifier?: string | undefined;
};
/**
 * An item that shows a menu when pressed.
 */
export type NativeStackHeaderItemMenu = SharedHeaderItem & {
    type: 'menu';
    /**
     * Whether the menu is a selection menu.
     * Tapping an item in a selection menu will add a checkmark to the selected item.
     *
     * Read more: https://developer.apple.com/documentation/uikit/uibarbuttonitem/changesselectionasprimaryaction
     */
    changesSelectionAsPrimaryAction?: boolean | undefined;
    /**
     * Menu for the item.
     */
    menu: {
        /**
         * Optional title to show on top of the menu.
         */
        title?: string | undefined;
        /**
         * Whether multiple items in the submenu can be selected, i.e. in "on" state.
         *
         * Defaults to `true`.
         *
         * Read more: https://developer.apple.com/documentation/uikit/uimenu/options-swift.struct/singleselection
         */
        multiselectable?: boolean | undefined;
        /**
         * How the submenu items are displayed.
         * - `default`: menu items are displayed normally.
         * - `palette`: menu items are displayed in a horizontal row.
         *
         * Defaults to `default`.
         *
         * Read more: https://developer.apple.com/documentation/uikit/uimenu/options-swift.struct/displayaspalette
         */
        layout?: 'default' | 'palette' | undefined;
        /**
         * Function called when the user checks or unchecks toggle items in the menu.
         *
         * In a single selection menu, i.e. `multiselectable: false`,
         * toggle items in nested submenus are part of the same selection.
         * So it also receives them, and `onChange` of the nested submenus isn't called.
         */
        onChange?: ((event: NativeStackHeaderMenuChangeEvent) => void) | undefined;
        /**
         * Array of menu items (actions, toggles or submenus).
         */
        items: (NativeStackHeaderItemMenuAction | NativeStackHeaderItemMenuToggle | NativeStackHeaderItemMenuSubmenu)[];
    } & NativeStackNextHeaderItemMenuOptions;
};
/**
 * An item to add spacing between other items in the header.
 */
export type NativeStackHeaderItemSpacing = {
    type: 'spacing';
    /**
     * The amount of spacing to add.
     */
    spacing: number;
};
/**
 * A custom item to display any React Element in the header.
 */
export type NativeStackHeaderItemCustom = {
    type: 'custom';
    /**
     * A React Element to display as the item.
     */
    element: React.ReactElement;
    /**
     * Whether the background this item may share with other items in the bar should be hidden.
     * Only available from iOS 26.0 and later.
     *
     * Read more: https://developer.apple.com/documentation/uikit/uibarbuttonitem/hidessharedbackground
     */
    hidesSharedBackground?: boolean | undefined;
};
/**
 * An item that can be displayed in the header.
 * It can be a button, a menu, spacing, or a custom element.
 *
 * On iOS 26, when showing items on the right side of the header,
 * if the items don't fit the available space, they will be collapsed into a menu automatically.
 * Items with `type: 'custom'` will not be included in this automatic collapsing behavior.
 */
export type NativeStackHeaderItem = NativeStackHeaderItemButton | NativeStackHeaderItemMenu | NativeStackHeaderItemSpacing | NativeStackHeaderItemCustom;
/**
 * Icon supported by native Android header controls in the experimental stack.
 */
export type NativeStackHeaderIconAndroid = Extract<Icon, {
    type: 'image' | 'materialSymbol';
}>;
type NativeStackHeaderToolbarMenuItemBase = {
    identifier: string;
    label?: string | undefined;
    condensedLabel?: string | undefined;
    tooltip?: string | undefined;
    accessibilityLabel?: string | undefined;
    hidden?: boolean | undefined;
    disabled?: boolean | undefined;
    showAsAction?: 'always' | 'alwaysWithText' | 'ifRoom' | 'ifRoomWithText' | 'never' | undefined;
    icon?: NativeStackHeaderIconAndroid | undefined;
    iconTintColor?: ColorValue | undefined;
    iconTintColorPressed?: ColorValue | undefined;
    iconTintColorFocused?: ColorValue | undefined;
    iconTintColorDisabled?: ColorValue | undefined;
};
/**
 * An item in the native Android toolbar menu.
 */
export type NativeStackHeaderToolbarMenuItem = NativeStackHeaderToolbarMenuItemBase & {
    type: 'item';
    onPress?: (() => void) | undefined;
};
/**
 * An item in the native Android toolbar menu that can be checked and unchecked by the user.
 *
 * When shown in the toolbar with `showAsAction`, it doesn't show whether it's checked.
 */
export type NativeStackHeaderToolbarMenuToggle = NativeStackHeaderToolbarMenuItemBase & {
    type: 'toggle';
    /**
     * Identifier of the group the item belongs to.
     */
    groupIdentifier: string;
    /**
     * Whether the item is checked when the menu is first shown.
     *
     * Defaults to `false`.
     */
    defaultChecked?: boolean | undefined;
};
/**
 * Selection behavior for a group of native Android toolbar menu items.
 */
export type NativeStackHeaderToolbarMenuGroup = {
    identifier: string;
    /**
     * Whether only one item in the group can be selected.
     *
     * Defaults to `false`.
     */
    singleSelection?: boolean | undefined;
    /**
     * Function called when the user checks or unchecks toggle items in the group.
     */
    onChange?: ((event: NativeStackHeaderMenuChangeEvent) => void) | undefined;
};
type NativeStackHeaderToolbarMenuBase = {
    groups?: NativeStackHeaderToolbarMenuGroup[] | undefined;
    items?: NativeStackHeaderToolbarMenuElement[] | undefined;
};
/**
 * A submenu in the native Android toolbar menu.
 */
export type NativeStackHeaderToolbarSubmenu = NativeStackHeaderToolbarMenuItemBase & NativeStackHeaderToolbarMenuBase & {
    type: 'menu';
    menuLabel?: string | undefined;
};
/**
 * An element in the native Android toolbar menu.
 */
export type NativeStackHeaderToolbarMenuElement = NativeStackHeaderToolbarMenuItem | NativeStackHeaderToolbarMenuToggle | NativeStackHeaderToolbarSubmenu;
/**
 * Options that can be updated imperatively for a toolbar menu element.
 */
export type NativeStackHeaderToolbarMenuElementOptions = Partial<Omit<NativeStackHeaderToolbarMenuItemBase, 'identifier'>> & {
    checked?: boolean | undefined;
    menuLabel?: string | undefined;
};
/**
 * Methods for updating the native Android toolbar menu.
 */
export type NativeStackHeaderToolbarMenuRef = {
    setOptions: (identifier: string, options: NativeStackHeaderToolbarMenuElementOptions) => void;
};
/**
 * Configuration for the native Android toolbar menu.
 */
export type NativeStackHeaderToolbarMenu = NativeStackHeaderToolbarMenuBase & {
    ref?: React.Ref<NativeStackHeaderToolbarMenuRef> | undefined;
};
export type NativeStackNavigatorProps = DefaultNavigatorOptions<ParamListBase, StackNavigationState<ParamListBase>, NativeStackNavigationOptions, NativeStackNavigationEventMap, NativeStackNavigationProp<ParamListBase>> & StackRouterOptions & NativeStackNavigationConfig;
export type NativeStackDescriptor = Descriptor<NativeStackNavigationOptions, NativeStackNavigationProp<ParamListBase>, RouteProp<ParamListBase>>;
export type NativeStackDescriptorMap = {
    [key: string]: NativeStackDescriptor;
};
export {};
//# sourceMappingURL=types.d.ts.map