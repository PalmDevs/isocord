import {
  getDefaultHeaderHeight,
  getHeaderTitle,
  HeaderBackContext,
  HeaderHeightContext,
  HeaderShownContext,
  useFrameSize,
} from '@react-navigation/elements';
import {
  ActivityView,
  SafeAreaProviderCompat,
} from '@react-navigation/elements/internal';
import {
  NavigationProvider,
  type ParamListBase,
  StackActions,
  type StackNavigationState,
  usePreventRemoveContext,
  useTheme,
} from '@react-navigation/native';
import * as React from 'react';
import {
  Animated,
  Platform,
  StyleSheet,
  useAnimatedValue,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  type ScreenProps,
  ScreenStack,
  ScreenStackItem,
} from 'react-native-screens';

import type {
  NativeStackDescriptor,
  NativeStackDescriptorMap,
  NativeStackNavigationHelpers,
} from '../types';
import { debounce } from '../utils/debounce';
import { getModalRouteKeys } from '../utils/getModalRoutesKeys';
import { AnimatedHeaderHeightContext } from '../utils/useAnimatedHeaderHeight';
import { useDismissedRouteError } from '../utils/useDismissedRouteError';
import { useInvalidPreventRemoveError } from '../utils/useInvalidPreventRemoveError';
import { useHeaderConfigProps } from './useHeaderConfigProps';

const ANDROID_DEFAULT_HEADER_HEIGHT = 56;

type SceneViewProps = {
  index: number;
  focused: boolean;
  descriptor: NativeStackDescriptor;
  previousDescriptor?: NativeStackDescriptor | undefined;
  isPresentationModal: boolean;
  isNextScreenTransparent: boolean;
  isNextScreenSheet: boolean;
  isNextScreenModal: boolean;
  isInactive: boolean;
  isBeforeLast: boolean;
  hasNestedState: boolean;
  stateKey: string;
  emit: NativeStackNavigationHelpers['emit'];
  dispatch: NativeStackNavigationHelpers['dispatch'];
  setNextDismissedKey: (key: string) => void;
};

const useNativeDriver = Platform.OS !== 'web';

const TRANSPARENT_PRESENTATIONS = [
  'transparentModal',
  'containedTransparentModal',
];

const SHEET_PRESENTATIONS = ['formSheet', 'pageSheet'];

const SceneView = React.memo(function SceneView({
  index,
  focused,
  descriptor,
  previousDescriptor,
  isPresentationModal,
  isNextScreenTransparent,
  isNextScreenSheet,
  isNextScreenModal,
  isInactive,
  isBeforeLast,
  hasNestedState,
  stateKey,
  emit,
  dispatch,
  setNextDismissedKey,
}: SceneViewProps) {
  const { route, navigation, options, render } = descriptor;

  const onWillDisappear = () => {
    emit({
      type: 'transitionStart',
      data: { closing: true },
      target: route.key,
    });
  };

  const onWillAppear = () => {
    emit({
      type: 'transitionStart',
      data: { closing: false },
      target: route.key,
    });
  };

  const onAppear = () => {
    emit({
      type: 'transitionEnd',
      data: { closing: false },
      target: route.key,
    });
  };

  const onDisappear = () => {
    emit({
      type: 'transitionEnd',
      data: { closing: true },
      target: route.key,
    });
  };

  const onDismissed: ScreenProps['onDismissed'] = (event) => {
    if (isInactive) {
      return;
    }

    dispatch({
      ...StackActions.dismiss(event.nativeEvent.dismissCount),
      source: route.key,
      target: stateKey,
    });

    setNextDismissedKey(route.key);
  };

  const onHeaderBackButtonClicked = () => {
    dispatch({
      ...StackActions.pop(),
      source: route.key,
      target: stateKey,
    });
  };

  const onNativeDismissCancelled: ScreenProps['onDismissed'] = (event) => {
    dispatch({
      ...StackActions.dismiss(event.nativeEvent.dismissCount),
      source: route.key,
      target: stateKey,
    });
  };

  const onGestureCancel = () => {
    emit({
      type: 'gestureCancel',
      target: route.key,
    });
  };

  const onSheetDetentChanged: ScreenProps['onSheetDetentChanged'] = (event) => {
    emit({
      type: 'sheetDetentChange',
      target: route.key,
      data: {
        index: event.nativeEvent.index,
        stable: event.nativeEvent.isStable,
      },
    });
  };

  const {
    inactiveBehavior = 'pause',
    animation,
    animationDuration,
    animationMatchesGesture,
    animationTypeForReplace = 'push',
    fullScreenGestureEnabled,
    fullScreenGestureShadowEnabled = true,
    gestureEnabled,
    gestureDirection,
    gestureResponseDistance,
    header,
    headerBackButtonMenuEnabled,
    headerShown,
    headerBackground,
    headerTransparent,
    autoHideHomeIndicator,
    keyboardHandlingEnabled,
    navigationBarHidden,
    orientation,
    sheetAllowedDetents = [1.0],
    sheetLargestUndimmedDetentIndex = -1,
    sheetGrabberVisible = false,
    sheetCornerRadius = -1.0,
    sheetElevation = 24,
    sheetExpandsWhenScrolledToEdge = true,
    sheetInitialDetentIndex = 0,
    sheetShouldOverflowTopInset = false,
    sheetResizeAnimationEnabled = true,
    statusBarAnimation,
    statusBarHidden,
    statusBarStyle,
    unstable_headerInsets,
    unstable_sheetFooter,
    scrollEdgeEffects,
    contentStyle,
  } = options;

  let { presentation = isPresentationModal ? 'modal' : 'card' } = options;

  if (index === 0) {
    // first screen should always be treated as `card`, it resolves problems with no header animation
    // for navigator with first screen as `modal` and the next as `card`
    presentation = 'card';
  }

  const { colors } = useTheme();
  const insets = useSafeAreaInsets();

  // `modal`, `formSheet` and `pageSheet` presentations do not take whole screen, so should not take the inset.
  const isModal =
    presentation === 'modal' ||
    presentation === 'formSheet' ||
    presentation === 'pageSheet';

  // Modals are fullscreen in landscape only on iPhone
  const isIPhone = Platform.OS === 'ios' && !(Platform.isPad || Platform.isTV);

  const isParentHeaderShown = React.use(HeaderShownContext);
  const parentHeaderHeight = React.use(HeaderHeightContext);
  const parentHeaderBack = React.use(HeaderBackContext);

  const isLandscape = useFrameSize((frame) => frame.width > frame.height);

  const topInset =
    isParentHeaderShown ||
    (Platform.OS === 'android' && unstable_headerInsets?.top === false) ||
    (Platform.OS === 'ios' && isModal) ||
    (isIPhone && isLandscape)
      ? 0
      : insets.top;

  const defaultHeaderHeight = useFrameSize((frame) =>
    Platform.select({
      // FIXME: Currently screens isn't using Material 3
      // So our `getDefaultHeaderHeight` doesn't return the correct value
      // So we hardcode the value here for now until screens is updated
      android: ANDROID_DEFAULT_HEADER_HEIGHT + topInset,
      default: getDefaultHeaderHeight({
        landscape: frame.width > frame.height,
        modalPresentation: isModal,
        topInset,
      }),
    })
  );

  const { preventedRoutes } = usePreventRemoveContext();

  const [headerHeight, setHeaderHeight] = React.useState(defaultHeaderHeight);

  // eslint-disable-next-line @eslint-react/exhaustive-deps
  const setHeaderHeightDebounced = React.useCallback(
    // Debounce the header height updates to avoid excessive re-renders
    debounce(setHeaderHeight, 100),
    []
  );

  const hasCustomHeader = header != null;

  const canGoBack = previousDescriptor != null || parentHeaderBack != null;
  const backTitle = previousDescriptor
    ? getHeaderTitle(previousDescriptor.options, previousDescriptor.route.name)
    : parentHeaderBack?.title;

  const headerBack = React.useMemo(() => {
    if (canGoBack) {
      return {
        href: undefined, // No href needed for native
        title: backTitle,
      };
    }

    return undefined;
  }, [canGoBack, backTitle]);

  const isRemovePrevented = preventedRoutes[route.key]?.preventRemove;

  const animatedHeaderHeight = useAnimatedValue(defaultHeaderHeight);

  const headerConfig = useHeaderConfigProps({
    ...options,
    route,
    headerBackButtonMenuEnabled:
      isRemovePrevented !== undefined
        ? !isRemovePrevented
        : headerBackButtonMenuEnabled,
    headerBackTitle:
      options.headerBackTitle !== undefined
        ? options.headerBackTitle
        : undefined,
    headerHeight,
    headerShown: header !== undefined ? false : headerShown,
    headerBack,
  });

  const headerContainerRef =
    React.useRef<React.ComponentRef<typeof View>>(null);

  React.useLayoutEffect(() => {
    headerContainerRef.current?.measure((_x, _y, _width, height) => {
      animatedHeaderHeight.setValue(height);
      setHeaderHeight(height);
    });
  }, [animatedHeaderHeight]);

  const onHeaderHeightChange = hasCustomHeader
    ? // If we have a custom header, don't use native header height
      undefined
    : // On Fabric, there's a bug where native event drivers for Animated objects
      // are created after the first notifications about the header height
      // from the native side, `onHeaderHeightChange` event does not notify
      // `animatedHeaderHeight` about initial values on appearing screens at the moment.
      Animated.event(
        [
          {
            nativeEvent: {
              headerHeight: animatedHeaderHeight,
            },
          },
        ],
        {
          useNativeDriver,
          listener: (e) => {
            if (
              e.nativeEvent &&
              typeof e.nativeEvent === 'object' &&
              'headerHeight' in e.nativeEvent &&
              typeof e.nativeEvent.headerHeight === 'number'
            ) {
              const headerHeight = e.nativeEvent.headerHeight;

              // Only debounce if header has large title or search bar
              // As it's the only case where the header height can change frequently
              const doesHeaderAnimate =
                Platform.OS === 'ios' &&
                (options.headerLargeTitleEnabled ||
                  options.headerSearchBarOptions);

              if (doesHeaderAnimate) {
                setHeaderHeightDebounced(headerHeight);
              } else {
                if (
                  Platform.OS === 'android' &&
                  headerHeight !== 0 &&
                  // On some devices, height maybe slightly off (e.g. 56.17 instead of 56)
                  Math.round(headerHeight) <= ANDROID_DEFAULT_HEADER_HEIGHT
                ) {
                  // FIXME: On Android, events may get delivered out-of-order
                  // https://github.com/facebook/react-native/issues/54636
                  // We seem to get header height without status bar height first,
                  // and then the correct height with status bar height included
                  // But due to out-of-order delivery, we may get the correct height first
                  // and then the one without status bar height
                  // This is hack to include status bar height if it's not already included
                  // It only works because header height doesn't change dynamically on Android
                  setHeaderHeight(headerHeight + insets.top);
                } else {
                  setHeaderHeight(headerHeight);
                }
              }
            }
          },
        }
      );

  // Nested navigators clean up `route.state` when the screen is paused with `Activity`
  // So we remember if the route had state until the screen is removed
  const [hadNestedState, setHadNestedState] = React.useState(hasNestedState);

  if (hasNestedState && !hadNestedState) {
    setHadNestedState(true);
  }

  const activityMode =
    // Render focused screens normally
    // Unpause preloaded and retained screens so updates are visible
    // Unpause previous screen so update isn't delayed for swipe back
    // This lets effects on those screens run
    // We don't need to handle inert as it'll be handled natively
    inactiveBehavior === 'none' ||
    focused ||
    isInactive ||
    isNextScreenTransparent ||
    // Unpause the screen behind a sheet so it stays up to date
    // Sheets don't cover the whole screen, so the screen behind is visible
    isNextScreenSheet ||
    // On iPadOS, the base screen is visible while modal is in a smaller area
    // So also keep the screens unpaused
    (isNextScreenModal && !isModal) ||
    isBeforeLast
      ? 'normal'
      : inactiveBehavior === 'unmount' && !hadNestedState
        ? 'unmounted'
        : 'paused';

  const content = (
    <AnimatedHeaderHeightContext.Provider value={animatedHeaderHeight}>
      <HeaderHeightContext.Provider
        value={headerShown !== false ? headerHeight : (parentHeaderHeight ?? 0)}
      >
        {headerShown !== false && headerBackground != null ? (
          /**
           * To show a custom header background, we render it at the top of the screen below the header
           * The header also needs to be positioned absolutely (with `translucent` style)
           */
          <View
            style={[
              styles.background,
              headerTransparent ? styles.translucent : null,
              { height: headerHeight },
            ]}
          >
            {headerBackground()}
          </View>
        ) : null}
        {header != null && headerShown !== false ? (
          <View
            style={[
              styles.header,
              headerTransparent
                ? [
                    styles.absolute,
                    // Specify an explicit min height for Android screen readers
                    { minHeight: headerHeight },
                  ]
                : null,
            ]}
          >
            <View
              ref={headerContainerRef}
              onLayout={(e) => {
                const headerHeight = e.nativeEvent.layout.height;

                animatedHeaderHeight.setValue(headerHeight);
                setHeaderHeight(headerHeight);
              }}
              style={{ pointerEvents: 'box-none' }}
            >
              {header({
                back: headerBack,
                options,
                route,
                navigation,
              })}
            </View>
          </View>
        ) : null}
        <HeaderShownContext.Provider
          value={isParentHeaderShown || headerShown !== false}
        >
          <HeaderBackContext.Provider value={headerBack}>
            {render()}
          </HeaderBackContext.Provider>
        </HeaderShownContext.Provider>
      </HeaderHeightContext.Provider>
    </AnimatedHeaderHeightContext.Provider>
  );

  return (
    <NavigationProvider navigation={navigation} route={route}>
      <ScreenStackItem
        key={route.key}
        screenId={route.key}
        activityState={isInactive ? 0 : 2}
        style={StyleSheet.absoluteFill}
        aria-hidden={!focused}
        customAnimationOnSwipe={animationMatchesGesture}
        fullScreenSwipeEnabled={fullScreenGestureEnabled}
        fullScreenSwipeShadowEnabled={fullScreenGestureShadowEnabled}
        gestureEnabled={
          Platform.OS === 'android'
            ? // This prop enables handling of system back gestures on Android
              // Since we handle them in JS side, we disable this
              false
            : gestureEnabled
        }
        homeIndicatorHidden={autoHideHomeIndicator}
        hideKeyboardOnSwipe={keyboardHandlingEnabled}
        navigationBarHidden={navigationBarHidden}
        replaceAnimation={animationTypeForReplace}
        stackPresentation={presentation === 'card' ? 'push' : presentation}
        stackAnimation={animation}
        screenOrientation={orientation}
        sheetAllowedDetents={sheetAllowedDetents}
        sheetLargestUndimmedDetentIndex={sheetLargestUndimmedDetentIndex}
        sheetGrabberVisible={sheetGrabberVisible}
        sheetInitialDetentIndex={sheetInitialDetentIndex}
        sheetCornerRadius={sheetCornerRadius}
        sheetElevation={sheetElevation}
        sheetExpandsWhenScrolledToEdge={sheetExpandsWhenScrolledToEdge}
        sheetShouldOverflowTopInset={sheetShouldOverflowTopInset}
        sheetDefaultResizeAnimationEnabled={sheetResizeAnimationEnabled}
        statusBarAnimation={statusBarAnimation}
        statusBarHidden={statusBarHidden}
        statusBarStyle={statusBarStyle}
        swipeDirection={gestureDirection}
        transitionDuration={animationDuration}
        onWillAppear={onWillAppear}
        onWillDisappear={onWillDisappear}
        onAppear={onAppear}
        onDisappear={onDisappear}
        onDismissed={onDismissed}
        onGestureCancel={onGestureCancel}
        onSheetDetentChanged={onSheetDetentChanged}
        gestureResponseDistance={gestureResponseDistance}
        nativeBackButtonDismissalEnabled={false} // on Android
        onHeaderBackButtonClicked={onHeaderBackButtonClicked}
        preventNativeDismiss={isRemovePrevented} // on iOS
        scrollEdgeEffects={{
          bottom: scrollEdgeEffects?.bottom ?? 'automatic',
          top: scrollEdgeEffects?.top ?? 'automatic',
          left: scrollEdgeEffects?.left ?? 'automatic',
          right: scrollEdgeEffects?.right ?? 'automatic',
        }}
        onNativeDismissCancelled={onNativeDismissCancelled}
        onHeaderHeightChange={onHeaderHeightChange}
        contentStyle={[
          presentation !== 'transparentModal' &&
            presentation !== 'containedTransparentModal' && {
              backgroundColor: colors.background,
            },
          contentStyle,
        ]}
        headerConfig={headerConfig}
        unstable_sheetFooter={unstable_sheetFooter}
      >
        {activityMode === 'unmounted' ? null : (
          <ActivityView
            mode={activityMode}
            visible={
              // We don't need to hide the content since it's handled natively
              // Hiding may also cause flash due to lag after native tab switch
              // So we leave it always visible
              true
            }
            style={styles.content}
          >
            {content}
          </ActivityView>
        )}
      </ScreenStackItem>
    </NavigationProvider>
  );
});

type Props = {
  state: StackNavigationState<ParamListBase>;
  navigation: NativeStackNavigationHelpers;
  descriptors: NativeStackDescriptorMap;
};

export function NativeStackView({ state, navigation, descriptors }: Props) {
  const { colors } = useTheme();
  const { setNextDismissedKey } = useDismissedRouteError(state);

  useInvalidPreventRemoveError(descriptors);

  const activeRoutes = state.routes.slice(0, state.index + 1);
  const modalRouteKeys = getModalRouteKeys(activeRoutes, descriptors);

  return (
    <SafeAreaProviderCompat>
      <ScreenStack
        style={styles.container}
        nativeContainerStyle={{ backgroundColor: colors.background }}
      >
        {state.routes.map((route, index) => {
          const descriptor = descriptors[route.key];

          if (descriptor == null) {
            throw new Error(
              `Couldn't find a descriptor for route '${route.key}'.`
            );
          }

          const isFocused = state.index === index;
          const previousKey = activeRoutes[index - 1]?.key;
          const nextKey = activeRoutes[index + 1]?.key;
          const previousDescriptor = previousKey
            ? descriptors[previousKey]
            : undefined;
          const nextDescriptor = nextKey ? descriptors[nextKey] : undefined;

          const nextPresentation = nextDescriptor?.options.presentation;

          const isNextScreenTransparent =
            nextPresentation != null &&
            TRANSPARENT_PRESENTATIONS.includes(nextPresentation);
          const isNextScreenSheet =
            nextPresentation != null &&
            SHEET_PRESENTATIONS.includes(nextPresentation);
          const isNextScreenModal = nextKey
            ? modalRouteKeys.includes(nextKey)
            : false;

          const isModal = modalRouteKeys.includes(route.key);

          return (
            <SceneView
              key={route.key}
              index={index}
              focused={isFocused}
              descriptor={descriptor}
              previousDescriptor={previousDescriptor}
              isPresentationModal={isModal}
              isNextScreenTransparent={isNextScreenTransparent}
              isNextScreenSheet={isNextScreenSheet}
              isNextScreenModal={isNextScreenModal}
              isInactive={index > state.index}
              isBeforeLast={index === activeRoutes.length - 2}
              hasNestedState={route.state != null}
              stateKey={state.key}
              emit={navigation.emit}
              dispatch={navigation.dispatch}
              setNextDismissedKey={setNextDismissedKey}
            />
          );
        })}
      </ScreenStack>
    </SafeAreaProviderCompat>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
  },
  header: {
    zIndex: 1,
  },
  absolute: {
    position: 'absolute',
    top: 0,
    start: 0,
    end: 0,
  },
  translucent: {
    position: 'absolute',
    top: 0,
    start: 0,
    end: 0,
    zIndex: 1,
    elevation: 1,
  },
  background: {
    overflow: 'hidden',
  },
});
