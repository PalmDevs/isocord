import { getHeaderTitle, HeaderTitle } from '@react-navigation/elements';
import { Color } from '@react-navigation/elements/internal';
import {
  MaterialSymbol,
  type Route,
  type Theme,
  useLocale,
  useTheme,
} from '@react-navigation/native';
import { useMemo, useState } from 'react';
import { Platform, StyleSheet, type TextStyle, View } from 'react-native';
import {
  type HeaderBarButtonItemMenuAction,
  type HeaderBarButtonItemSubmenu,
  type HeaderBarButtonItemVisibilityPriority,
  type HeaderBarButtonItemWithAction,
  type HeaderBarButtonItemWithMenu,
  isSearchBarAvailableForCurrentPlatform,
  ScreenStackHeaderBackButtonImage,
  ScreenStackHeaderCenterView,
  type ScreenStackHeaderConfigProps,
  ScreenStackHeaderLeftView,
  ScreenStackHeaderRightView,
  ScreenStackHeaderSearchBarView,
  SearchBar,
} from 'react-native-screens';

import type {
  NativeStackHeaderItem,
  NativeStackHeaderItemButton,
  NativeStackHeaderItemMenu,
  NativeStackHeaderItemMenuAction,
  NativeStackHeaderItemMenuSubmenu,
  NativeStackHeaderItemMenuToggle,
  NativeStackNavigationOptions,
} from '../types';

type Props = NativeStackNavigationOptions & {
  headerHeight: number;
  headerBack: { title?: string | undefined; href: undefined } | undefined;
  route: Route<string>;
};

type ToggleItemsState = {
  checked: Map<string, boolean>;
  onCheckedChange: (checked: Record<string, boolean>) => void;
};

type ToggleMenu = {
  toggleItems: NativeStackHeaderItemMenuToggle[];
  isSingleSelection: boolean;
  onChange: NativeStackHeaderItemMenu['menu']['onChange'];
};

const ICON_SIZE = 24;

const processBarButtonItems = (
  items: NativeStackHeaderItem[] | undefined,
  colors: Theme['colors'],
  fonts: Theme['fonts'],
  toggleItemsState: ToggleItemsState
) => {
  return items
    ?.map((item, index) => {
      if (item.type === 'custom') {
        // Handled with `ScreenStackHeaderLeftView` or `ScreenStackHeaderRightView`
        return null;
      }

      if (item.type === 'spacing') {
        if (item.spacing == null) {
          throw new Error(
            `Spacing item must have a 'spacing' property defined: ${JSON.stringify(
              item
            )}`
          );
        }

        return item;
      }

      if (item.type === 'button' || item.type === 'menu') {
        if (item.type === 'menu' && item.menu == null) {
          throw new Error(
            `Menu item must have a 'menu' property defined: ${JSON.stringify(
              item
            )}`
          );
        }

        const { badge, label, labelStyle, icon, visibilityPriority, ...rest } =
          item;

        const processedVisibilityPriority:
          | HeaderBarButtonItemVisibilityPriority
          | undefined =
          visibilityPriority === 'default' ? 'standard' : visibilityPriority;

        const processedItemCommon = {
          ...rest,
          index,
          title: label,
          titleStyle: {
            ...fonts.regular,
            ...labelStyle,
          },
          icon: transformIcon(icon),
          visibilityPriority: processedVisibilityPriority,
        };

        let processedItem:
          | HeaderBarButtonItemWithAction
          | HeaderBarButtonItemWithMenu;

        if (processedItemCommon.type === 'menu' && item.type === 'menu') {
          const { multiselectable, layout } = item.menu;

          const toggleMenu = getToggleMenu(item.menu);

          processedItem = {
            ...processedItemCommon,
            menu: {
              title: item.menu.title,
              singleSelection:
                typeof multiselectable === 'boolean'
                  ? !multiselectable
                  : undefined,
              displayAsPalette: layout === 'palette',
              items: item.menu.items.map((menuItem) =>
                getMenuItem(menuItem, toggleItemsState, toggleMenu)
              ),
            },
          };
        } else if (
          processedItemCommon.type === 'button' &&
          item.type === 'button'
        ) {
          processedItem = processedItemCommon;
        } else {
          throw new Error(
            `Invalid item type: ${JSON.stringify(item)}. Valid types are 'button' and 'menu'.`
          );
        }

        if (badge) {
          const badgeBackgroundColor =
            badge.style?.backgroundColor ?? colors.notification;
          const badgeTextColor = Color.foreground(badgeBackgroundColor);

          processedItem = {
            ...processedItem,
            badge: {
              ...badge,
              value: String(badge.value),
              style: {
                backgroundColor: badgeBackgroundColor,
                color: badgeTextColor,
                ...fonts.regular,
                ...badge.style,
              },
            },
          };
        }

        return processedItem;
      }

      throw new Error(
        `Invalid item type: ${JSON.stringify(item)}. Valid types are 'button', 'menu', 'custom' and 'spacing'.`
      );
    })
    .filter((item) => item != null);
};

const transformIcon = (
  icon: NativeStackHeaderItemButton['icon']
):
  | HeaderBarButtonItemWithAction['icon']
  | HeaderBarButtonItemWithMenu['icon'] => {
  if (icon?.type === 'image') {
    return icon.tinted === false
      ? { type: 'imageSource', imageSource: icon.source }
      : { type: 'templateSource', templateSource: icon.source };
  }

  return icon;
};

const getToggleMenu = (
  menu: Pick<
    NativeStackHeaderItemMenuSubmenu,
    'items' | 'multiselectable' | 'onChange'
  >
): ToggleMenu => {
  const isSingleSelection = menu.multiselectable === false;

  return {
    toggleItems: getToggleItems(menu.items, isSingleSelection),
    isSingleSelection,
    onChange: menu.onChange,
  };
};

const getToggleItems = (
  items: NativeStackHeaderItemMenuSubmenu['items'],
  includeSubmenus: boolean
): NativeStackHeaderItemMenuToggle[] =>
  items.flatMap((item) => {
    if (item.type === 'toggle') {
      return [item];
    }

    if (item.type === 'submenu' && includeSubmenus) {
      return getToggleItems(item.items, includeSubmenus);
    }

    return [];
  });

const getMenuItem = (
  item:
    | NativeStackHeaderItemMenuAction
    | NativeStackHeaderItemMenuToggle
    | NativeStackHeaderItemMenuSubmenu,
  toggleItemsState: ToggleItemsState,
  toggleMenu: ToggleMenu
): HeaderBarButtonItemMenuAction | HeaderBarButtonItemSubmenu => {
  if (item.type === 'submenu') {
    const submenuToggleMenu = toggleMenu.isSingleSelection
      ? toggleMenu
      : getToggleMenu(item);

    return {
      type: 'submenu',
      icon: transformIcon(item.icon),
      title: item.label,
      subtitle: item.description,
      destructive: item.destructive,
      displayAsPalette: item.layout === 'palette',
      displayInline: item.inline,
      singleSelection:
        typeof item.multiselectable === 'boolean'
          ? !item.multiselectable
          : undefined,
      items: item.items.map((submenuItem) =>
        getMenuItem(submenuItem, toggleItemsState, submenuToggleMenu)
      ),
    };
  }

  if (item.type === 'toggle') {
    const isChecked =
      toggleItemsState.checked.get(item.identifier) ??
      item.defaultChecked ??
      false;

    return {
      type: 'action',
      icon: transformIcon(item.icon),
      title: item.label,
      subtitle: item.description,
      state: isChecked ? 'on' : 'off',
      disabled: item.disabled,
      destructive: item.destructive,
      hidden: item.hidden,
      keepsMenuPresented: item.keepsMenuPresented,
      discoverabilityLabel: item.discoverabilityLabel,
      onPress: () => {
        if (toggleMenu.isSingleSelection && isChecked) {
          return;
        }

        const checked = Object.fromEntries(
          toggleMenu.toggleItems.map((toggleItem) => [
            toggleItem.identifier,
            toggleItem.identifier === item.identifier
              ? !isChecked
              : !toggleMenu.isSingleSelection &&
                (toggleItemsState.checked.get(toggleItem.identifier) ??
                  toggleItem.defaultChecked ??
                  false),
          ])
        );

        toggleItemsState.onCheckedChange(checked);
        toggleMenu.onChange?.({ checked });
      },
    };
  }

  const { label, icon, description, ...rest } = item;

  return {
    ...rest,
    icon: transformIcon(icon),
    title: label,
    subtitle: description,
  };
};

export function useHeaderConfigProps({
  headerBackIcon,
  headerBackButtonDisplayMode,
  headerBackButtonMenuEnabled,
  headerBackTitle,
  headerBackTitleStyle,
  headerBackVisible,
  headerShadowVisible,
  headerLargeStyle,
  headerLargeTitleEnabled,
  headerLargeTitleShadowVisible,
  headerLargeTitleStyle,
  headerBackground,
  headerLeft,
  headerLeftBackgroundVisible,
  headerRight,
  headerRightBackgroundVisible,
  headerShown,
  headerStyle,
  headerBlurEffect,
  headerTintColor,
  headerTitle,
  headerTitleAlign,
  headerTitleStyle,
  headerTransparent,
  headerSearchBarOptions,
  headerBack,
  route,
  title,
  unstable_headerInsets: headerInsets,
  unstable_headerLeftItems: headerLeftItems,
  unstable_headerRightItems: headerRightItems,
}: Props): ScreenStackHeaderConfigProps {
  const { direction } = useLocale();
  const { colors, fonts, dark } = useTheme();

  const [checkedToggleItems, setCheckedToggleItems] = useState(
    () => new Map<string, boolean>()
  );

  const toggleItemsState: ToggleItemsState = {
    checked: checkedToggleItems,
    onCheckedChange: (checked) =>
      setCheckedToggleItems(
        (previous) => new Map([...previous, ...Object.entries(checked)])
      ),
  };

  const tintColor =
    headerTintColor ?? (Platform.OS === 'ios' ? colors.primary : colors.text);

  const headerBackTitleStyleFlattened =
    StyleSheet.flatten([fonts.regular, headerBackTitleStyle]) || {};
  const headerLargeTitleStyleFlattened =
    StyleSheet.flatten([
      Platform.select({ ios: fonts.heavy, default: fonts.medium }),
      headerLargeTitleStyle,
    ]) || {};
  const headerTitleStyleFlattened =
    StyleSheet.flatten([
      Platform.select({ ios: fonts.bold, default: fonts.medium }),
      headerTitleStyle,
    ]) || {};
  const headerStyleFlattened = StyleSheet.flatten(headerStyle) || {};
  const headerLargeStyleFlattened = StyleSheet.flatten(headerLargeStyle) || {};

  const headerBackgroundColor =
    headerStyleFlattened.backgroundColor ??
    (headerBackground != null ||
    headerTransparent ||
    // The title becomes invisible if background color is set with large title on iOS 26
    (Platform.OS === 'ios' && headerLargeTitleEnabled)
      ? 'transparent'
      : colors.card);

  const backTitleFontSize =
    'fontSize' in headerBackTitleStyleFlattened
      ? headerBackTitleStyleFlattened.fontSize
      : undefined;
  const backTitleFontFamily = headerBackTitleStyleFlattened.fontFamily;

  const titleText = getHeaderTitle({ title, headerTitle }, route.name);
  const titleColor =
    'color' in headerTitleStyleFlattened
      ? headerTitleStyleFlattened.color
      : Platform.OS === 'ios' &&
          (headerTransparent || headerBackgroundColor === 'transparent')
        ? // On iOS 26, we want header title to change color based on content underneath
          // So we don't set an explicit color when header is transparent
          // Unless a custom tint color is explicitly provided
          headerTintColor
        : (headerTintColor ?? colors.text);
  const titleFontSize =
    'fontSize' in headerTitleStyleFlattened
      ? headerTitleStyleFlattened.fontSize
      : undefined;
  const titleFontWeight = headerTitleStyleFlattened.fontWeight;
  const titleFontFamily = headerTitleStyleFlattened.fontFamily;

  const largeTitleBackgroundColor = headerLargeStyleFlattened.backgroundColor;
  const largeTitleColor =
    'color' in headerLargeTitleStyleFlattened
      ? headerLargeTitleStyleFlattened.color
      : undefined;
  const largeTitleFontSize =
    'fontSize' in headerLargeTitleStyleFlattened
      ? headerLargeTitleStyleFlattened.fontSize
      : undefined;
  const largeTitleFontWeight = headerLargeTitleStyleFlattened.fontWeight;
  const largeTitleFontFamily = headerLargeTitleStyleFlattened.fontFamily;

  const headerTitleStyleSupported: TextStyle = {
    color: titleColor,
    ...(titleFontFamily != null ? { fontFamily: titleFontFamily } : null),
    ...(titleFontSize != null ? { fontSize: titleFontSize } : null),
    ...(titleFontWeight != null ? { fontWeight: titleFontWeight } : null),
  };

  const canGoBack = headerBack != null;

  const headerLeftElement = headerLeft?.({
    tintColor,
    canGoBack,
    label: headerBackTitle ?? headerBack?.title,
    // `href` is only applicable to web
    href: undefined,
  });

  const headerRightElement = headerRight?.({
    tintColor,
    canGoBack,
  });

  const headerTitleElement =
    typeof headerTitle === 'function'
      ? headerTitle({
          tintColor,
          children: titleText,
        })
      : null;

  const hasHeaderSearchBar =
    isSearchBarAvailableForCurrentPlatform && headerSearchBarOptions != null;

  /**
   * We need to set this in if:
   * - Back button should stay visible when `headerLeft` is specified
   * - If `headerTitle` for Android is specified, so we only need to remove the title and keep the back button
   */
  const backButtonInCustomView =
    headerBackVisible ||
    (Platform.OS === 'android' &&
      headerTitleElement != null &&
      headerLeftElement == null);

  const translucent =
    headerBackground != null ||
    headerTransparent ||
    // When using a SearchBar or large title, the header needs to be translucent for it to work on iOS
    ((hasHeaderSearchBar || headerLargeTitleEnabled) &&
      Platform.OS === 'ios' &&
      headerTransparent !== false);

  const isBackButtonDisplayModeAvailable =
    // On iOS 14+
    Platform.OS === 'ios' &&
    parseInt(Platform.Version, 10) >= 14 &&
    // Doesn't have custom styling, by default System, see: https://github.com/software-mansion/react-native-screens/pull/2105#discussion_r1565222738
    (backTitleFontFamily == null || backTitleFontFamily === 'System') &&
    backTitleFontSize == null &&
    // Back button menu is not disabled
    headerBackButtonMenuEnabled !== false;

  const isCenterViewRenderedAndroid = headerTitleAlign === 'center';

  const leftItems = headerLeftItems?.({
    tintColor,
    canGoBack,
  });

  let rightItems = headerRightItems?.({
    tintColor,
    canGoBack,
  });

  if (rightItems) {
    // iOS renders right items in reverse order
    // So we need to reverse them here to match the order
    rightItems = [...rightItems].reverse();
  }

  const backImageSource = useMemo(() => {
    if (headerShown === false || headerBackVisible === false) {
      return undefined;
    }

    if (
      headerBackIcon == null &&
      Platform.OS === 'android' &&
      MaterialSymbol.isAvailable()
    ) {
      // Use Material Symbol as default back icon on Android
      // So it's consistent with other material icons
      // Based on the available variant and weight
      return MaterialSymbol.getImageSource({
        name: 'arrow_back',
        color: tintColor,
        size: ICON_SIZE,
        direction,
      });
    } else if (headerBackIcon?.type === 'image') {
      return headerBackIcon.source;
    } else if (headerBackIcon?.type === 'materialSymbol') {
      return MaterialSymbol.getImageSource({
        name: headerBackIcon.name,
        variant: headerBackIcon.variant,
        weight: headerBackIcon.weight,
        fill: headerBackIcon.fill,
        color: tintColor,
        size: ICON_SIZE,
        direction,
      });
    }

    return undefined;
  }, [direction, headerBackIcon, headerBackVisible, headerShown, tintColor]);

  const children = (
    <>
      {Platform.OS === 'ios' ? (
        <>
          {leftItems ? (
            leftItems.map((item, index) => {
              if (item.type === 'custom') {
                return (
                  <ScreenStackHeaderLeftView
                    // eslint-disable-next-line @eslint-react/no-array-index-key
                    key={index}
                    hidesSharedBackground={item.hidesSharedBackground}
                  >
                    {item.element}
                  </ScreenStackHeaderLeftView>
                );
              }

              return null;
            })
          ) : headerLeftElement != null ? (
            <ScreenStackHeaderLeftView
              hidesSharedBackground={headerLeftBackgroundVisible === false}
            >
              {headerLeftElement}
            </ScreenStackHeaderLeftView>
          ) : null}
          {headerTitleElement != null ? (
            <ScreenStackHeaderCenterView>
              {headerTitleElement}
            </ScreenStackHeaderCenterView>
          ) : null}
        </>
      ) : (
        <>
          {headerLeftElement != null || typeof headerTitle === 'function' ? (
            // The style passed to header left, together with title element being wrapped
            // in flex view is required for proper header layout, in particular,
            // for the text truncation to work.
            <ScreenStackHeaderLeftView
              style={!isCenterViewRenderedAndroid ? { flex: 1 } : null}
            >
              {headerLeftElement}
              {headerTitleAlign !== 'center' ? (
                typeof headerTitle === 'function' ? (
                  <View style={{ flex: 1 }}>{headerTitleElement}</View>
                ) : (
                  <View style={{ flex: 1 }}>
                    <HeaderTitle
                      tintColor={tintColor}
                      style={headerTitleStyleSupported}
                    >
                      {titleText}
                    </HeaderTitle>
                  </View>
                )
              ) : null}
            </ScreenStackHeaderLeftView>
          ) : null}
          {isCenterViewRenderedAndroid ? (
            <ScreenStackHeaderCenterView>
              {typeof headerTitle === 'function' ? (
                headerTitleElement
              ) : (
                <HeaderTitle
                  tintColor={tintColor}
                  style={headerTitleStyleSupported}
                >
                  {titleText}
                </HeaderTitle>
              )}
            </ScreenStackHeaderCenterView>
          ) : null}
        </>
      )}
      {backImageSource != null ? (
        <ScreenStackHeaderBackButtonImage source={backImageSource} />
      ) : null}
      {Platform.OS === 'ios' && rightItems ? (
        rightItems.map((item, index) => {
          if (item.type === 'custom') {
            return (
              <ScreenStackHeaderRightView
                // eslint-disable-next-line @eslint-react/no-array-index-key
                key={index}
                hidesSharedBackground={item.hidesSharedBackground}
              >
                {item.element}
              </ScreenStackHeaderRightView>
            );
          }

          return null;
        })
      ) : headerRightElement != null ? (
        <ScreenStackHeaderRightView
          hidesSharedBackground={headerRightBackgroundVisible === false}
        >
          {headerRightElement}
        </ScreenStackHeaderRightView>
      ) : null}
      {hasHeaderSearchBar ? (
        <ScreenStackHeaderSearchBarView>
          <SearchBar
            {...headerSearchBarOptions}
            onChangeText={headerSearchBarOptions.onChange}
          />
        </ScreenStackHeaderSearchBarView>
      ) : null}
    </>
  );

  return {
    backButtonInCustomView,
    backgroundColor: headerBackgroundColor,
    backTitle: headerBackTitle,
    backTitleVisible: isBackButtonDisplayModeAvailable
      ? undefined
      : headerBackButtonDisplayMode !== 'minimal',
    backButtonDisplayMode: isBackButtonDisplayModeAvailable
      ? headerBackButtonDisplayMode
      : undefined,
    backTitleFontFamily,
    backTitleFontSize,
    blurEffect: headerBlurEffect,
    color: tintColor,
    direction,
    disableBackButtonMenu: headerBackButtonMenuEnabled === false,
    hidden: headerShown === false,
    hideBackButton: headerBackVisible === false,
    hideShadow:
      headerShadowVisible === false ||
      headerBackground != null ||
      (headerTransparent && headerShadowVisible !== true),
    largeTitle: headerLargeTitleEnabled,
    largeTitleBackgroundColor,
    largeTitleColor,
    largeTitleFontFamily,
    largeTitleFontSize,
    largeTitleFontWeight:
      largeTitleFontWeight != null ? String(largeTitleFontWeight) : undefined,
    largeTitleHideShadow: headerLargeTitleShadowVisible === false,
    title: titleText,
    titleColor,
    titleFontFamily,
    titleFontSize,
    titleFontWeight: String(titleFontWeight),
    disableTopInsetApplication:
      headerInsets?.top !== undefined ? !headerInsets.top : undefined,
    disableLeftInsetApplication:
      headerInsets?.left !== undefined ? !headerInsets.left : undefined,
    disableRightInsetApplication:
      headerInsets?.right !== undefined ? !headerInsets.right : undefined,
    disableBottomInsetApplication:
      headerInsets?.bottom !== undefined ? !headerInsets.bottom : undefined,
    translucent: translucent === true,
    children,
    headerLeftBarButtonItems: processBarButtonItems(
      leftItems,
      colors,
      fonts,
      toggleItemsState
    ),
    headerRightBarButtonItems: processBarButtonItems(
      rightItems,
      colors,
      fonts,
      toggleItemsState
    ),
    experimental_userInterfaceStyle: dark ? 'dark' : 'light',
  } as const;
}
