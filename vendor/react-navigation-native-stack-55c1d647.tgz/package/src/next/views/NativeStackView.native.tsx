import { SafeAreaProviderCompat } from '@react-navigation/elements/internal';
import {
  type ParamListBase,
  StackActions,
  type StackNavigationState,
  useLocale,
  useTheme,
} from '@react-navigation/native';
import * as React from 'react';
import { Stack } from 'react-native-screens';

import type {
  NativeStackDescriptorMap,
  NativeStackNavigationHelpers,
} from '../../types';
import { useDismissedRouteError } from '../../utils/useDismissedRouteError';
import { useInvalidPreventRemoveError } from '../../utils/useInvalidPreventRemoveError';
import { CardScreen } from './CardScreen';
import {
  type NativeStackViewState,
  type NativeStackViewStateAction,
  SUPPORTS_FORM_SHEET,
  useViewState,
} from './NativeStackViewState';
import { SheetScreen } from './SheetScreen';

type Props = {
  state: StackNavigationState<ParamListBase>;
  navigation: NativeStackNavigationHelpers;
  descriptors: NativeStackDescriptorMap;
};

type NativeStackViewContentProps = Props &
  Pick<NativeStackViewState, 'renderedRoutes' | 'poppedByKey'> & {
    dispatch: React.Dispatch<NativeStackViewStateAction>;
  };

function NativeStackViewContent({
  state,
  navigation,
  descriptors,
  renderedRoutes,
  poppedByKey,
  dispatch,
}: NativeStackViewContentProps) {
  useInvalidPreventRemoveError(descriptors);

  const { direction } = useLocale();
  const { dark } = useTheme();

  const { setNextDismissedKey } = useDismissedRouteError(state);

  const routeIndexByKey = new Map(
    state.routes.map((route, index) => [route.key, index])
  );

  const onRemovePoppedRoute = React.useCallback(
    (key: string) => {
      dispatch({ type: 'REMOVE_POPPED_ROUTE', key });
    },
    [dispatch]
  );

  const onNativeDismiss = React.useCallback(
    ({
      key,
      markNativelyDismissed,
    }: {
      key: string;
      markNativelyDismissed: boolean;
    }) => {
      const currentState = navigation.getState();
      const index = currentState.routes.findIndex((route) => route.key === key);
      const route = currentState.routes[index];

      if (route == null || index > currentState.index) {
        return;
      }

      if (markNativelyDismissed) {
        dispatch({
          type: 'ADD_NATIVELY_DISMISSED_ROUTES',
          keys: currentState.routes
            .slice(index, currentState.index + 1)
            .map((route) => route.key),
        });
      }

      navigation.dispatch({
        ...StackActions.dismiss(),
        source: key,
        target: currentState.key,
      });

      if (markNativelyDismissed) {
        setNextDismissedKey(key);
      }
    },
    [dispatch, navigation, setNextDismissedKey]
  );

  const onNativeDismissPrevented = React.useCallback(
    (key: string) => {
      const currentState = navigation.getState();
      const route = currentState.routes.find((route) => route.key === key);

      if (route == null) {
        return;
      }

      navigation.dispatch({
        ...StackActions.dismiss(),
        source: key,
        target: currentState.key,
      });
    },
    [navigation]
  );

  const { cards, sheets } = renderedRoutes.reduce<{
    cards: React.ReactElement[];
    sheets: React.ReactElement[];
  }>(
    (result, route) => {
      const index = routeIndexByKey.get(route.key);
      const popped = poppedByKey.get(route.key);
      const descriptor = descriptors[route.key] ?? popped?.descriptor;

      if (descriptor == null) {
        throw new Error(
          `Couldn't find descriptor for route ${route.name} (${route.key}). This is likely a bug.`
        );
      }

      const presentation = descriptor.options.presentation ?? 'card';

      if (presentation !== 'card' && presentation !== 'formSheet') {
        throw new Error(
          `The route '${route.name}' uses the '${presentation}' presentation, which is not supported in native stack. Only 'card' and 'formSheet' presentations are supported.`
        );
      }

      const isPopped = popped != null;
      const isSheet = SUPPORTS_FORM_SHEET && presentation === 'formSheet';

      const props = {
        descriptor,
        navigation,
        isFocused: index === state.index,
        isPopped,
        onRemovePoppedRoute,
        onNativeDismiss,
        onNativeDismissPrevented,
      };

      if (isSheet) {
        if (index === 0) {
          throw new Error(
            `The route '${route.name}' cannot use 'formSheet' presentation because it is the first route in the native stack. Add a screen with 'card' presentation before it.`
          );
        }

        const routeAboveSheet =
          index != null && index < state.index
            ? state.routes[index + 1]
            : undefined;

        if (routeAboveSheet != null) {
          throw new Error(
            `The route '${routeAboveSheet.name}' was pushed above the form sheet route '${route.name}' in the same native stack. A form sheet does not create a nested stack automatically. Render a nested navigator inside '${route.name}' and push '${routeAboveSheet.name}' on that nested navigator instead.`
          );
        }

        result.sheets.push(<SheetScreen key={route.key} {...props} />);
      } else {
        const previousRoute =
          index == null ? undefined : state.routes[index - 1];

        const previousDescriptor = isPopped
          ? popped?.previousDescriptor
          : previousRoute == null
            ? undefined
            : descriptors[previousRoute.key];

        result.cards.push(
          <CardScreen
            key={route.key}
            {...props}
            previousDescriptor={previousDescriptor}
            isBeforeLast={index === state.index - 1}
            isDetached={index != null && index > state.index}
            hasNestedState={index != null && state.routes[index]?.state != null}
          />
        );
      }

      return result;
    },
    { cards: [], sheets: [] }
  );

  return (
    <SafeAreaProviderCompat>
      <Stack.Host direction={direction} colorScheme={dark ? 'dark' : 'light'}>
        {cards}
      </Stack.Host>
      {sheets}
    </SafeAreaProviderCompat>
  );
}

export function NativeStackView({ state, navigation, descriptors }: Props) {
  const [{ renderedRoutes, poppedByKey }, dispatch] = useViewState({
    state,
    descriptors,
  });

  return (
    <NativeStackViewContent
      state={state}
      navigation={navigation}
      descriptors={descriptors}
      renderedRoutes={renderedRoutes}
      poppedByKey={poppedByKey}
      dispatch={dispatch}
    />
  );
}
